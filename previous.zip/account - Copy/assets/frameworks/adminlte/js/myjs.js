/**
 * Created by MZ on 18/8/2016.
 */
//0=text, 1=flash, 2=unicode
function count_message(read,write,msg_type,include_enter,max_sms){
    if(include_enter == null || include_enter == undefined)
        include_enter = true;

    if(max_sms == undefined)
        max_sms = 5000;

    var num = count__(read,include_enter);

    var len = document.getElementById(msg_type);
    var my = [160,160,70];
    var length = my[len];

    var result = "";

    if(num == 0){
        result = num+"/"+length+" (0 SMS)";

    }else if(num > max_sms){
        result = num+" Maximum sms character reached (5000)";

    }else if(num > length){

        var x = 0;
        var b = 3;
        if(length == 160){
            x = Math.ceil(num/length) * 7;
            b = 7;
        }else{
            x = Math.ceil(num/length) * 3;
        }

        var y = x + num;
        var z = Math.ceil(y/length);
        var a = (z * length) - (z * b);
        result = num+"/"+a+" ("+z+" SMS)";

    }else{
        result = num+"/"+length+" (1 SMS)";
    }

    var z = document.getElementById(write);

    z.innerHTML = result;
    return num;
}

function count__(read, include_enter){
    if(include_enter == null || include_enter == undefined)
        include_enter = true;

    var field = document.getElementById(read);
    var extraChars = 0;
    for(var i = 0; i<field.value.length; i++){
        if (field.value.charAt(i) == '^') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '{') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '}') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '\\') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '[') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '~') {
            extraChars++;
        }
        else if (field.value.charAt(i) == ']') {
            extraChars++;
        }
        else if (field.value.charAt(i) == '|') {
            extraChars++;
        } else if (field.value.charAt(i) == '\n' && include_enter) {
            extraChars++;
        }
        else if (field.value.charCodeAt(i) == 0x20AC) {
            extraChars++;
        }
        extraChars++;
    }
    return extraChars;
}

function count_sender(read,write,progress){
        var s = document.getElementById(read);
        if($.isNumeric(s.value))
            max_sender = 14;
        else
            max_sender = 11;

        s.maxLength = max_sender;
        var x = s.value;
        if(x.length > max_sender){
            s.value = x.substring(0,max_sender);
        }


        var y = document.getElementById(write);
        if(y != null) {
            var z = max_sender - x.length;
            y.innerHTML = z + " character(s) left";
        }

        var p = document.getElementById(progress);
        if(p != null) {
            var z = (x.length/max_sender) * 100;
            p.style.width = Math.floor(z)+"%";
        }
    return x.length;
}

$(function(){

    $('a').each(function()
    {
        var x = $(this).attr('href');

        x = x.toLowerCase().trim();

        if (x.indexOf("#") !== 0 && x.indexOf("javascript") !== 0)
        {
            $(this).click(function(){
                $('<div class="loadingDiv"><i class="fa fa-spinner fa-spin"></i><br>Please wait...</div>').prependTo(document.getElementById('main-body'));
                setTimeout(function() { $(".loadingDiv").fadeOut(1500); }, 15000);
            });
        }
    });

});

$(function(){
    $("form").submit(function(e){
        $('<div class="loadingDiv"><i class="fa fa-spinner fa-spin"></i><br>Please wait...</div>').prependTo(document.getElementById('main-body'));
        setTimeout(function() { $(".loadingDiv").fadeOut(1500); }, 15000);
    });
});

$(function(){
    $('#close-message').click(function(){
        setTimeout(function() { $(".loadingDiv").fadeOut(1500); }, 1500);
    });
});

$(function(){
    $('#closeBox').click(function(){
        setTimeout(function() { $(".loadingDiv").fadeOut(1500); }, 1500);
    });
});
$(function(){
    $('.src').click(function(){
        setTimeout(function() { $(".loadingDiv").fadeOut(1500); }, 1500);
    });
});

var _isSidebarClose = false;
function showAjaxModal(url,class_)
{
    jQuery('#modal_ajax .modal-body').html('<div style="text-align:center;margin-top:200px;"><img src="../assets/images/preloader.gif" /></div>');
    if(class_ != undefined){
        jQuery('.modal-dialog').addClass(class_);
    }

    jQuery('#modal_ajax').modal('show', {backdrop: 'true'});

    _isSidebarClose = jQuery('body').hasClass('sidebar-collapse');

    if(_isSidebarClose == false){
        jQuery('body').addClass('sidebar-collapse');
    }
    $.ajax({
        url: url,
        success: function(response)
        {
            jQuery('#modal_ajax .modal-body').html(response);
        }
    });


}

jQuery('#modal_ajax').on('hidden.bs.modal', function () {
    if(_isSidebarClose == false){
        jQuery('body').removeClass('sidebar-collapse');
    }
    // do something�
})

function confirm_modal(delete_url)
{
    jQuery('#modal-4').modal('show', {backdrop: 'static'});
    document.getElementById('delete_link').setAttribute('href' , delete_url);
}