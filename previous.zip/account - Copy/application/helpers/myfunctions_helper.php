<?php
/**
 * Created by PhpStorm.
 * User: MZ
 * Date: 20/8/2016
 * Time: 8:15 PM
 */

if ( ! function_exists('get_setting'))
{
		function get_setting($key,$default = ""){

			static $settings = null;
			if(!isset($settings[reseller_id()][$key])){
				$q = db()->get_where('settings' , array('field'=>$key,'reseller_id'=>reseller_id()));

				if($q -> num_rows() > 0){
					$settings[reseller_id()][$key] = $q -> row() -> value;;
				}else {
					$data['reseller_id'] = reseller_id();
					$data['field'] = $key;
					$data['value'] = $default;
					if(db()->insert("settings", $data)){
						$settings[reseller_id()][$key] = $default;
					}
				}
			}


			return $settings[reseller_id()][$key];
		}
}



if ( ! function_exists('save_setting'))
{
	function save_setting($key,$value=""){
		$rid = reseller_id();
		if(!is_array($key)){
			$key = array($key=>$value);
		}
		$success = 0;
		foreach($key as $k => $v) {
			$q = db()->get_where('settings', array('field' => $k, 'reseller_id' => $rid));
			if ($q->num_rows() > 0) {
				db()->where("reseller_id",$rid);
				db()->where("field",$k);
				if(db()->update("settings",array("value"=>$value)))
					$success++;
			} else {
				$data['reseller_id'] = reseller_id();
				$data['field'] = $k;
				$data['value'] = $v;
				if (db()->insert("settings", $data)) {
					$success++;
				}
			}

		}

		if($success == count($key))
			return true;

		if($success == 0)
			return false;

		return $success;
	}
}

if ( ! function_exists('reseller_id'))
{
	function reseller_id(){
		if(isset($GLOBALS['RESELLER_ID'])){
			return $GLOBALS['RESELLER_ID'];
		}
		return 0;
	}
}

function checkAccess($config=Array()){
//		$this->myAccess($config['function']);
//		return isset($_SESSION['login_type']);
		return true;

	if(!isset($config['function']))
		$config['function'] = debug_backtrace()[1]['function'];

	if(!isset($config['redirect']))
		$config['redirect'] = true;

	if(!isset($config['refresh']))
		$config['refresh'] = false;

	$access = $this->userdata("access");
	$access = is_array($access)?$access:explode(",",$access);

	$spec_access = $this->userdata("specific_access");
	$spec_access = is_null($spec_access) || $spec_access == ""?Array():(is_array($spec_access)?$spec_access:explode(",",$spec_access));

	if(count($spec_access) > 0 && in_array($config['function'],$spec_access)){
		return true;
	}else if(count($spec_access) == 0 && count($access) > 0 && in_array($config['function'],$access)){
		return true;
	}else{
		if($config['redirect']){
			$this->set_flashdata('flash_message' , get_phrase('access_denied_('.$config['function'].')'));
			redirect(base_url() . '?members/dashboard', $config['refresh']?'refresh':'refresh');
		}
	}

	return false;
}

function hAccess($function=null){
	$config = Array("redirect"=>false);
	if(!empty($function))
		$config['function'] = $function;

	return checkAccess($config);
}

function rAccess($function=null,$refresh = false){
return true;
	$config = Array("redirect"=>true);
	if(!empty($function)) {
		$config['function'] = $function;
	}
	$config['refresh'] = $refresh;
	return checkAccess($config);
}

function ss(){
	$CI =& get_instance();
	return $CI->session;
}

function s(){
	$CI =& get_instance();
	return $CI->session;
}

function m(){
	$CI =& get_instance();
	return $CI->mine;
}

function d(){
	$CI =& get_instance();
	return $CI->db;
}

function &this(){
	return get_instance();
}

function user_id(){
	return this()->session->userdata('user_id');
}

function isAdmin($user_id = ""){
	if($user_id != ""){
		return db()->get("members",array("id",$user_id))->row()->isAdmin === 1;
	}

	return ss()->userdata("isAdmin") === 1;
}

function isReseller($user_id = ""){
	if($user_id != "") {
		return db()->get("members", array("id", $user_id))->row()->isReseller === 1;
	}
	return ss()->userdata("isReseller") === 1;
}

function in_arrayi($needle, $haystack) {
	return in_array(strtolower($needle), array_map('strtolower', $haystack));
}

