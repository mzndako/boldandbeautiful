<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mine {

    protected $CI;

    public function __construct()
    {	
		$this->CI =& get_instance();
    }


    function get_form($options = array("required_all"=>false)){
        $table = isset($options['table'])?$options['table']:"members";
        $parent = db()->get($table)->result_array();

        $required_all = isset($options['required_all'])?$options['required_all']:true;

        $except = isset($options['except'])?explode(",",$options['except']):array();

        $fields = db()->list_fields("members");

        $my_access = $this->all_access();
        foreach($my_access as $k => $v)
            $my_access[$k] = str_replace("_"," ",ucwords($v));

        $selected = array();
        if(isset($options['values']['access'])){
//            print_r($options['values']);
//            die($options['values']['access']);
            $selected = explode(",",$options['values']['access']);
        }

        $change = array(
            "student_id"=>array("type"=>"hidden"),
            "surname" => array("label"=>"Surname","required"=>true),
            "first_name" => array("label"=>"First Name","required"=>true),
            "last_name" => array("label"=>"Last Name","required"=>true),
            "middle_name" => array("label"=>"Middle Name","required"=>false),
            "sex" => array("type"=>"radio", "options"=>array("male","female")),
            "lga" => array("label"=>"LGA"),
            "password" => array("type"=>"password"),
            "country" => array("value"=>"Nigeria"),
            "others" => array("label"=>"Other Relevant Information"),
            "address" => array("type"=>"textarea"),
            "next_of_kin_address" => array("type"=>"textarea"),
            "access" => array("type"=>"checkbox","name"=>"access[]","options"=>$my_access,"multiple"=>true, "label"=>"Specific Access","value"=>$selected),
            "religion" => array("type"=>"select","options"=>array("muslim"=>"Muslim","christian"=>"Christian","others"=>"Others"))
        );

        $studentform = array();

        foreach($fields as $field){

            if(isset($options['values'])){
                $student = $options['values'];
                $studentform[$field]['value'] = isset($student[$field])?$student[$field]:"";
            }
            $studentform[$field]['type'] = "text";
            $studentform[$field]['name'] = $field;
            $studentform[$field]['label'] = ucwords(str_replace(array("c1","c2","_","address1","address2"),array("",""," ","Home Address","Office Address"),$field));

            if($required_all){
                $studentform[$field]['required'] = !in_array($field,$except);
            }else{
                $studentform[$field]['required'] = in_array($field,$except);
            }
            if(isset($change[$field])){
                $row = $change[$field];
                if(isset($row['type'])){
                    $studentform[$field]['type'] = $row['type'];
                }
                if(isset($row['label'])){
                    $studentform[$field]['label'] = $row['label'];
                }
                if(isset($row['options'])){
                    $studentform[$field]['options'] = $row['options'];
                }

                if(isset($row['required'])){
                    $studentform[$field]['required'] = $row['required'];
                }

                if(isset($row['value'])){
                    $studentform[$field]['value'] = $row['value'];
                }


            }
        }
        return $studentform;

    }

    function create_input($options){
        $name = isset($options['name'])?$options['name']:"";
        $label = isset($options['label'])?$options['label']:"Value";
        $type = isset($options['type'])?$options['type']:"text";
        $value = isset($options['value'])?$options['value']:"";
        $class = isset($options['class'])?$options['class']:"form-control";
        $showclass = isset($options['showclass'])?$options['showclass']:"text-warning";
        $required = isset($options['required']) && $options['required']?"data-validate='required' data-message-required='$label Required'":"";
        $op = isset($options['options'])?$options['options']:array();
        $onlyshow = isset($options['onlyshow'])?$options['onlyshow']:false;

        if($onlyshow){
            $show = $value;
            if($type == "select" || $type == "radio" || $type == "checkbox"){
                $show = "";
                if(is_array($value)){
                    $show = implode(", ",$value);
                }else {
                    foreach ($op as $k => $v) {
                        if ($k == $value) {
                            $show = ucwords($v);
                            break;
                        }
                    }
                }
            }

            if($type == "password"){
                $show = "*********";
            }

            if($type == "image"){
                $options['type'] = $options['type_'];
                return $this->construct_image($options);
            }

            return "<span class='$showclass form-control' style='border: none; color: #4e1c1c;'>$show</span>";
        }

        $value = is_array($value)?$value:htmlspecialchars($value);

        if($type == "textarea"){
            return "<textarea class='$class' rows='4' name='$name' $required>$value</textarea>";
        }

        if($type == "select"){
            $multiple = "";
            if(isset($options['multiple']) && $options['multiple']){
                $multiple = "multiple='multiple'";
                $class .= " select2";
            }

            $str = "<select class='$class' $multiple $required name='$name'>";
            if($multiple == ""){
                $str .= "<option value=''>Select $label</option>";
            }
            foreach($op as $k => $v){
                if(is_array($value)){
                    $s = in_array($v,$value)?"selected":"";
                }else
                    $s = strtolower($k) == strtolower($value)?"selected":"";

                $str .= "<option $s value='$k'>".ucwords($v)."</option>";
            }
            $str .= "</select>";
            return $str;
        }

        if($type == "checkbox" || $type == "radio"){
            $str = "";
            $name .= is_array($value)?"[]":"";
            foreach($op as $v){
                $v1 = ucwords($v);
                if(is_array($value)){
//                    print_r($value); print $v;
                    $s = in_arrayi($v,$value)?"checked=checked":"";
                }else
                    $s = $v == $value?"checked=checked":"";

                $str .= "<div class='$type'><label><input $s type='$type' name='$name'
value='$v'
 $required> $v1 </label></div>";
            }
            return $str."";
        }

        if($type == "password"){
            $width = 70;
            if($value == ""){
                $width = 100;
            }
            return "<input style='width: $width%; display: inline-block' ".($value== ""?"":"disabled='disabled'")." type='$type' value='**********' name='$name' id='$name' class='$class' $required >".($value == ""?"":"<input style='width: 29%; margin-left: 1%; display: inline-block; ' type='button' class='btn btn-success' onclick=\"$('#$name').removeAttr('disabled').val('').attr('required','required');\" value='change'>");
        }

        if($type == "image"){
            $options['type'] = $options['type_'];
            return $this->construct_image($options);
        }

        return "<input type='$type' value='$value' name='$name' id='$name' class='$class'
$required >";
    }

    function all_access($id = null){
            $array = array('login','view_staffs','manage_staffs','view_customers','manage_customers','view_appointments','manage_appointments','view_calendar','manage_calendar','send_message','change_user_password' );
        if($id != null){
            $id = strtolower(str_replace(' ','_',$id));
            return isset($array[$id])?$array[$id]:"";
        }
        return $array;
    }

    function get_image_path($type){
        $x = $type == ""?"/":"/$type/";
        return "upload".$x;
    }

    function get_file_name($type,$id,$id_prefix = null){
        if($id_prefix == null || $id_prefix == ""){
            $id = $type."_".$id;
        }else
            $id = $id_prefix."_".$id;
        return $id.".jpg";
    }
    ////////IMAGE URL//////////
    function get_image_url($type = '', $id = '',$id_prefix = null) {

        $path = $this->get_image_path($type);
        $file = $this->get_file_name($type,$id,$id_prefix);

        $image = $path.$file;
        if (file_exists($image))
            $image_url = base_url() . $image;
        else {
            if($type == "") $type = "logo";
            $image_url = base_url() . 'upload/' . $type . ".jpg";
        }

        return $image_url;
    }

    function move_image($source,$type,$id,$id_prefix=null){
        $path = $this->get_image_path($type);
        if(!is_dir($path)){
            mkdir($path, 0777, true);
        }
        $file = $this->get_file_name($type,$id,$id_prefix);
        return move_uploaded_file($_FILES[$source]['tmp_name'], $path.$file);
    }

    function construct_image($options){
        $type = isset($options['type'])?$options['type']:"user";
        $id = isset($options['id'])?$options['id']:-1;
        $id_prefix = isset($options['id_prefix'])?$options['id_prefix']:null;
        $onlyshow = isset($options['onlyshow'])?$options['onlyshow']:false;
        $name = isset($options['name'])?$options['name']:"image";
        $image_link = $this->get_image_url($type,$id,$id_prefix);
        if($onlyshow){
            return '
            <div>
            <a href="'.$image_link.'" title="Click to View" target="_blank"><img style="width: 100px; height: 100px;"
            src="'.$image_link.'"
            alt="'.$type.'"></a>
            </div>
            ';
        }
        return '
        <div class="fileinput fileinput-new" data-provides="fileinput" >
								<div data-validate=required data-message-required=Required class="fileinput-new thumbnail" style="width: 100px; height: 100px;" data-trigger="fileinput">
									<img src="'.$image_link.'" alt="...">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
								<div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="'.$name.'" accept="image/*">
									</span>
									<a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
								</div>
							</div>

        ';
    }


    function get_full_name($row){
        if(is_object($row))
            return ucwords($row->last_name." ".$row->first_name." ".$row->middle_name);

        return ucwords($row['last_name']." ".$row['first_name']." ".$row['middle_name']);
    }
}