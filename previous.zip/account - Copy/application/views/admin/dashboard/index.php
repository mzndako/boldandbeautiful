<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>






<div class="content-wrapper">
                <section class="content-header">
                    <?php echo $pagetitle; ?>
                    <?php echo $breadcrumb; ?>
                </section>

                <section class="content">
                    <?php echo $dashboard_alert_file_install; ?>


                 <div class="row">


                        <div class="col-md-12">
                            <?php
                            /*
							if ($url_exist) {
								echo 'OK';
							} else {
								echo 'KO';
							}
							*/
                            ?>
                        </div>

                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-header with-border">
                                    <h3 class="box-title">DASHBOARD</h3>
                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    </div>
                                </div>
                                <div class="box-body">
                                    <div class="row">

                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="row">
                                                    <!-- CALENDAR-->
                                                    <div class="col-md-12 col-xs-12">
                                                        <div class="panel panel-primary " data-collapsed="0">
                                                            <div class="panel-heading">
                                                                <div class="panel-title">
                                                                    <i class="fa fa-calendar"></i>
                                                                    <?php echo get_phrase('appointment_schedule');?>
                                                                </div>
                                                            </div>
                                                            <div class="panel-body" style="padding:0px;">
                                                                <div class="calendar-env">
                                                                    <div class="calendar-body">
                                                                        <div id="calendar"></div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <div class="tile-stats tile-red">
                                                            <div class="icon"><i class="fa fa-group"></i></div>
                                                            <div class="num" data-start="0" data-end="<?php

                                                            //                    $q = $this->db->where("division_id",$this->session->userdata("division_id"));
                                                            $query = d()->get_where('members','isAdmin = 0') ;
                                                            echo	$query->num_rows();

                                                            ?>"
                                                                 data-postfix="" data-duration="1500" data-delay="0"> <?=$query->num_rows();?></div>

                                                            <h3><?php echo get_phrase('customers');
                                                                //                                                $q = $this->db->get("student")->get_compiled_select();
                                                                //                        echo $q;

                                                                ?></h3>
                                                            <p>Total Customers</p>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-12">

                                                        <div class="tile-stats tile-green">
                                                            <div class="icon"><i class="entypo-users"></i></div>
                                                            <div class="num" data-start="0" data-end="<?php
                                                            $query = d()->get_where('members','isAdmin = 1') ;
                                                            echo	$query->num_rows();
                                                            ?>"
                                                                 data-postfix="" data-duration="800" data-delay="0"> <?=$query->num_rows();?></div>

                                                            <h3><?php echo get_phrase('staff');?></h3>
                                                            <p>Total staffs</p>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-12">
                                                        <div id="myfirstchart" style="height: 250px;"></div>


                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <!-- CALENDAR-->
                        <div class="col-md-12 col-xs-12">
                            <div class="panel panel-primary " data-collapsed="0">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <i class="fa fa-calendar"></i>
                                        <?php echo get_phrase('event_schedule');?>
                                    </div>
                                </div>
                                <div class="panel-body" style="padding:0px;">
<!--                                    <div class="calendar-env">-->
<!--                                        <div class="calendar-body">-->

<!--                                        </div>-->
<!--                                    </div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
<style>
    .fc-button{
        padding: 0 .7em !important;
        line-height: 2em !important;;
    }
    .calendar-env .calendar-body {
        width: 99% !important;;
    }
    .calendar-env .calendar-body .fc-content .fc-view table tbody tr td.fc-day{
        border-bottom: none !important;
    }
</style>
<script src="<?php echo base_url($frameworks_dir . '/jquery/jquery.min.js'); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        Morris.Line({
            element: 'myfirstchart',
            data: [
                { year: '2008', value: 20 },
                { year: '2009', value: 10 },
                { year: '2010', value: 5 },
                { year: '2011', value: 5 },
                { year: '2012', value: 20 }
            ],

            xkey: 'year',

            ykeys: ['value'],

            labels: ['Value']
        });
    });

    var eventData;
    $(document).ready(function() {

        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },

            navLinks: true,
            selectable: true,
            selectHelper: true,
            select: function(start, end) {
                var title = prompt('Event Titless:');
                alert(start);
                alert(end);
                if (title) {
                    eventData = {
                        title: title,
                        start: start,
                        end: end
                    };
                    $('#calendar').fullCalendar('renderEvent', eventData, true);
                }
                $('#calendar').fullCalendar('unselect');
            },
            editable: true,
            eventLimit: true,
            events: [
                {
                    title: 'All Day Event',
                    start: '2016-09-01'
                },
                {
                    title: 'Long Event',
                    start: '2016-09-07',
                    end: '2016-09-10'
                },
                {
                    id: 999,
                    title: 'Repeating Event',
                    start: '2016-09-09T16:00:00'
                },
                {
                    id: 999,
                    title: 'Repeating Event',
                    start: '2016-09-16T16:00:00'
                },
                {
                    title: 'Conference',
                    start: '2016-09-11',
                    end: '2016-09-13'
                },
                {
                    title: 'Meeting',
                    start: '2016-09-12T10:30:00',
                    end: '2016-09-12T12:30:00'
                },
                {
                    title: 'Lunch',
                    start: '2016-09-12T12:00:00'
                },
                {
                    title: 'Meeting',
                    start: '2016-09-12T14:30:00'
                },
                {
                    title: 'Happy Hour',
                    start: '2016-09-12T17:30:00'
                },
                {
                    title: 'Dinner',
                    start: '2016-09-12T20:00:00'
                },
                {
                    title: 'Birthday Party',
                    start: '2016-09-13T07:00:00'
                },
                {
                    title: 'Click for Google',
                    url: 'http://google.com/',
                    start: '2016-09-28'
                }
            ]
        });

    });


    $(document).ready(function() {
        my_cal();
    });

    function my_cal(){
        var calendar = $('#notice_calendar');

        $('#notice_calendar').fullCalendar({
            header: {
                left: 'prev,next today title',
                right: 'month,basicWeek,basicDay'
            },



            editable: false,

            events: [
                <?php
				$notices	=	d()->get('members')->result_array();
				$notices	=	array();
				foreach($notices as $row):
				?>
                {
                    title: "<?php echo $row['first_name'];?>",
                    start: new Date(<?php echo date('Y',$row['last_login']);?>, <?php echo date('m',$row['last_login'])-1;?>, <?php echo date('d',$row['last_login']);?>),
                    end:	new Date(<?php echo date('Y',$row['last_login']);?>, <?php echo date('m',$row['last_login'])-1;?>, <?php echo date('d',$row['last_login']);?>)
                },
                <?php
				endforeach
				?>

            ]
        });
    };
</script>
