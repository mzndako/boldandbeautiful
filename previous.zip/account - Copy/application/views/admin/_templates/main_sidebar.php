<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

            <aside class="main-sidebar" style="z-index: 2000;">
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="<?php echo base_url($avatar_dir . '/m_001.png'); ?>" class="img-circle" alt="User Image">
                        </div>
                        <div class="pull-left info">
                            <p><?php echo $user_login['firstname'].$user_login['lastname']; ?></p>
                            <a href="#"><i class="fa fa-circle text-success"></i> <?php echo lang('menu_online'); ?></a>
                        </div>
                    </div>

                    <!-- Sidebar menu -->
                    <ul class="sidebar-menu">

                        <li class="<?=active_link_controller('dashboard')?>">
                            <a href="<?php echo site_url('members/dashboard'); ?>">
                                <i class="fa fa-dashboard"></i> <span><?php echo lang('menu_dashboard'); ?></span>
                            </a>
                        </li>

                        <li class="treeview <?=active_link_controller('appointments')?>">
                            <a href="<?php echo site_url('members/appointments'); ?>">
                                <i class="fa fa-cogs"></i>
                                <span><?php echo lang('appointments'); ?></span>

                            </a>

                        </li>

                        <li class="active " >
                            <a href="#">
                                <i class="fa fa-cogs"></i>
                                <span><?php echo 'ADMINISTRATOR'; ?></span>

                            </a>

                        </li>

                        <li class="<?=active_link_controller('staffs')?>">
                            <a href="<?php echo site_url('members/staffs'); ?>">
                                <i class="fa fa-shield"></i> <span><?php echo lang('staffs'); ?></span>
                            </a>
                        </li>
                        <li class="<?=active_link_controller('customers')?>">
                            <a href="<?php echo site_url('members/customers'); ?>">
                                <i class="fa fa-user"></i> <span><?php echo lang('customers'); ?></span>
                            </a>
                        </li>

                        <li class="<?=active_link_controller('calendar')?>">
                            <a href="<?php echo site_url('members/calendar'); ?>">
                                <i class="fa fa-file"></i> <span><?php echo lang('calendar'); ?></span>
                            </a>
                        </li>
                        <li class="<?=active_link_controller('sms')?>">
                            <a href="<?php echo site_url('members/sms'); ?>">
                                <i class="fa fa-envelope"></i> <span><?php echo lang('send_message'); ?></span>
                            </a>
                        </li>
                        <li class="<?=active_link_controller('records')?>">
                            <a href="<?php echo site_url('members/records'); ?>">
                                <i class="fa fa-database"></i> <span><?php echo lang('account_records'); ?></span>
                            </a>
                        </li>



                    </ul>
                </section>
            </aside>
