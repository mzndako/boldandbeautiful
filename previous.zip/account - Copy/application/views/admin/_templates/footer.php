<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

<!-- (Ajax Modal)-->
<div class="modal fade " id="modal_ajax">
	<div class="modal-dialog">
		<div class="modal-content ">

			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">BOLD AND BEAUTIFUL SALOON</h4>
			</div>

			<div class="modal-body" style="height:500px; overflow:auto;">



			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>


<!-- (Normal Modal)-->
<div class="modal fade" id="modal-4">
	<div class="modal-dialog">
		<div class="modal-content" style="margin-top:100px;">

			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" style="text-align:center;">Are you sure to delete this information ?</h4>
			</div>


			<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
				<a href="#" class="btn btn-danger" id="delete_link"><?php echo get_phrase('delete');?></a>
				<button type="button" class="btn btn-info" data-dismiss="modal"><?php echo get_phrase('cancel');?></button>
			</div>
		</div>
	</div>
</div>



<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b><?php echo lang('footer_version'); ?></b> 1.1.4
	</div>
	<strong><?php echo lang('footer_copyright'); ?> &copy; 2016-<?php echo date('Y'); ?> <a href="http://almsaeedstudio.com" target="_blank">Almsaeed Studio</a> &amp; <a href="http://domprojects.com" target="_blank">domProjects</a>.</strong> <?php echo lang('footer_all_rights_reserved'); ?>.
</footer>
</div>

<script src="<?php echo base_url($frameworks_dir . '/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url($frameworks_dir . '/bootstrap/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url($plugins_dir . '/slimscroll/slimscroll.min.js'); ?>"></script>
<?php if ($mobile == TRUE): ?>
	<script src="<?php echo base_url($plugins_dir . '/fastclick/fastclick.min.js'); ?>"></script>
<?php endif; ?>
<?php if ($admin_prefs['transition_page'] == TRUE): ?>
	<script src="<?php echo base_url($plugins_dir . '/animsition/animsition.min.js'); ?>"></script>
<?php endif; ?>
<?php if ($this->router->fetch_class() == 'users' && ($this->router->fetch_method() == 'create' OR $this->router->fetch_method() == 'edit')): ?>
	<script src="<?php echo base_url($plugins_dir . '/pwstrength/pwstrength.min.js'); ?>"></script>
<?php endif; ?>
<?php if ($this->router->fetch_class() == 'groups' && ($this->router->fetch_method() == 'create' OR $this->router->fetch_method() == 'edit')): ?>
	<script src="<?php echo base_url($plugins_dir . '/tinycolor/tinycolor.min.js'); ?>"></script>
	<script src="<?php echo base_url($plugins_dir . '/colorpickersliders/colorpickersliders.min.js'); ?>"></script>
<?php endif; ?>
<script src="<?php echo base_url($frameworks_dir . '/adminlte/js/adminlte.min.js'); ?>"></script>
<script src="<?php echo base_url($frameworks_dir . '/adminlte/js/pace.min.js'); ?>"></script>
<script src="<?php echo base_url($frameworks_dir . '/domprojects/js/dp.min.js'); ?>"></script>

<script src="<?php echo base_url($frameworks_dir . '/adminlte/js/myjs.js'); ?>"></script>

<script src="<?php echo base_url('assets/js/fileinput.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/dataTables.bootstrap.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/TableTools.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/dataTables.bootstrap.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/jquery.dataTables.columnFilter.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/lodash.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/responsive/js/datatables.responsive.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/select2/select2.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/selectboxit/jquery.selectBoxIt.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/toastr.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/morris.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/moment.js'); ?>"></script>
<script src="<?php echo base_url('assets/fullcalendar/fullcalendar.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/raphael-min.js'); ?>"></script>

<script type="text/javascript">

	jQuery(document).ready(function($)
	{


		var datatable = jQuery("#table_export").dataTable();

		jQuery(".dataTables_wrapper select").select2({
			minimumResultsForSearch: -1
		});

	});
	<?php if ($this->session->flashdata('flash_message') != ""):?>

		toastr.success('<?php echo $this->session->flashdata("flash_message");?>');

	<?php endif;?>


</script>
</body>
</html>