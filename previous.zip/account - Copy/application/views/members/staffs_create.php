<?php



$myform['Biodata'] = "myimage,last_name,first_name,middle_name,sex,phone,designation,specialization,email,password";
$myform['Address'] = "country,state,lga,address";
$myform['Next of Kin'] = "next_of_kin_name,next_of_kin_address,next_of_kin_phone";
$myform['Priviledges'] = "access";
?>
<h2><?php
	if($update > -1){
		echo m()->get_full_name($options['values']);
	}else
		echo "Add Staff";
	?></h2>
<ul class="nav nav-tabs bordered">
	<?php
	$active = "class='active'";
	foreach($myform as $header => $footer):
		$tag = str_replace(" ","",$header);
		$tag = str_replace("/","",$tag);
		?>
		<li <?php echo $active;?>><a data-toggle="tab" href="#<?php echo $tag;?>"><?php echo $header;?></a></li>
		<?php
		$active = "";
	endforeach;?>

</ul>
<?php
$link = "/create";
if($update > -1){
	$link = "/update/".$options['values']['id'];
}
echo form_open(site_url("members/staffs") .$link , array('class' => 'form-horizontal form-groups-bordered
validate',
	'enctype'
=> 'multipart/form-data', 'id'=>'myform'));
?>
<div class="tab-content">
	<?php


	$active = "in active";
	foreach($myform as $header => $footer):
		$tag = str_replace(" ","",$header);
		$tag = str_replace("/","",$tag);
		?>
		<div id="<?php echo $tag;?>" class="tab-pane fade <?php echo $active;?>">
			<?php
			if(is_array($footer)){
				echo '<ul class="nav nav-tabs bordered">';
				$act = "class='active'";
				foreach($footer as $h => $f){
					$tag = str_replace(" ","",$h);
					$tag = str_replace("/","",$tag);
					echo "
						<li $act><a data-toggle='tab' href='#$tag'>$h</a></li>
						";
					$act = '';
				}
				echo '</ul>';
			}else{
				echo '<h3>'.$header.'</h3>';
			}
			?>

			<div class="tab-content">
				<?php
				$loopf = array();
				if(is_array($footer)){
					$loopf = $footer;
				}else{
					$loopf["test"] = $footer;
				}
				$active2 = "in active";
				foreach($loopf as $h => $footer) {
					$tag = str_replace(" ","",$h);
					$tag = str_replace("/","",$tag);
					echo "<div id='$tag' class='tab-pane fade $active2'>";
					$footer = explode(",", $footer);
					foreach ($footer as $value) {
						if (!isset($form[$value]) && strpos($value,"!") === false) {
							if ($value == "myimage") {
								$options = array("type" => "user", "id" => $update, "onlyshow" => $onlyshow);
								echo "<center>" . m()->construct_image($options) . "</center>";
							}
							continue;
						}
						if(strpos($value,"!") !== false){
							$value = substr($value,1);
							$col = $value;
							$array['name'] = $value;
							$array['label'] = ucwords(str_replace("_"," ",$value));
							$array['id_prefix'] = $value;
							$array['type_'] = "teacher";
							$array['type'] = "image";
							$array['onlyshow'] = $onlyshow;
							$array['id'] = $update;
						}else {
							$col = $value;
							$array = $form[$value];
							$array['onlyshow'] = $onlyshow;
							$show = $array['type'] == "hidden" ? "style='display: none'" : "";
						}
						?>

						<div class="form-group" <?php echo $show; ?>>
							<label class="control-label col-xs-3" style="text-align: left;" for='<?php echo $col;
							?>'><?php echo
								$array['label']; ?>:</label>

							<div class="col-xs-8">
								<?php echo m()->create_input($array); ?>

							</div>
						</div>

					<?php }
					$active2 = "";
					echo '</div>';
				}
				$active = "";

				?>

			</div>
		</div>
	<?php endforeach;

	if(!$onlyshow):
		?>
		<center>
			<input type="submit" value="Save" name="save" class="btn btn-warning">
		</center>
	<?php endif; ?>
</div>
</form>
<script src="<?php echo base_url('assets/js/neon-custom-ajax.js'); ?>"></script>
