<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

<div class="content-wrapper">
	<section class="content-header">
		<?php echo $pagetitle; ?>
		<?php echo $breadcrumb; ?>
	</section>

	<section class="content">
		<div class="row">
			<div class="col-md-12">

				<!------CONTROL TABS START------>
				<ul class="nav nav-tabs bordered">
					<li class="active">
						<a href="#list" data-toggle="tab"><i class="entypo-menu"></i>
							<?php echo get_phrase('list of staffs');?>
						</a></li>
<!--					--><?php //if($s_->hAccess('manage_subject')): ?>
						<li>
							<a href="javascript:showAjaxModal('staffs/load/')" ><i class="entypo-plus-circled"></i>
								<?php echo get_phrase('add_staff');?>
							</a></li>
<!--					--><?php //endif; ?>

				</ul>
				<!------CONTROL TABS END------>
				<div class="tab-content">
					<!----TABLE LISTING STARTS-->
					<div class="tab-pane box active" id="list">

						<table class="table table-bordered datatable mytable" id="table_export">
							<thead>
							<tr>
								<th><div><?php echo get_phrase('staff id');?></div></th>
								<th><div><?php echo get_phrase('image');?></div></th>
								<th><div><?php echo get_phrase('full name');?></div></th>
								<th><div><?php echo get_phrase('designation');?></div></th>
								<th><div><?php echo get_phrase('specialization');?></div></th>
								<th><div><?php echo get_phrase('mobile number');?></div></th>
								<th><div><?php echo get_phrase('email');?></div></th>

								<th></th>
							</tr>
							</thead>
							<tbody>
							<?php

							foreach($staffs as $staff){
								?>
							<tr>
								<td><?=$staff['id'];?></td>
								<td><img src="<?=m()->get_image_url('user',$staff['id']);?>" alt="Staff Pix"  /></td>
								<td><?=m()->get_full_name($staff);?></td>
								<td><?=$staff['designation'];?></td>
								<td><?=$staff['specialization'];?></td>
								<td><?=$staff['phone'];?></td>
								<td><?=$staff['email'];?></td>
								<td>

									<div class="btn-group">
										<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
											Action <span class="caret"></span>
										</button>
										<ul class="dropdown-menu dropdown-default pull-right" role="menu">

											<!-- teacher EDITING LINK -->

											<li>
												<a href="#" onclick="showAjaxModal('<?php echo base_url("members/staffs/load/".$staff['id'].'/show');?>');">
													<i class="entypo-pencil"></i>
													<?php echo get_phrase('view');?>
												</a>
											</li>




											<?php if(hAccess('manage_staffs')): ?>
												<li>
													<a href="#" onclick="showAjaxModal('<?php echo base_url("members/staffs/load/".$staff['id']);?>');">
														<i class="entypo-pencil"></i>
														<?php echo get_phrase('edit');?>
													</a>
												</li>



												<li class="divider"></li>

												<!-- teacher DELETION LINK -->
												<li>
													<a href="#" onclick="confirm_modal('<?php echo base_url("members/staffs/delete/".$staff['id']);?>');">
														<i class="entypo-trash"></i>
														<?php echo get_phrase('delete');?>
													</a>
												</li>
											<?php endif; ?>
										</ul>
									</div>

								</td>
							</tr>
							<?php
							}
							?>
							</tbody>
						</table>
					</div>
					<!----TABLE LISTING ENDS--->


					<!----CREATION FORM STARTS---->

					<!----CREATION FORM ENDS-->

				</div>

			</div>
	</section>
</div>
