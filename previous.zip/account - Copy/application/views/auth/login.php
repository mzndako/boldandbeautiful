<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
            <div class="login-logo">
<!--                <a href="#"><b>BOLD</b> AND BEAUTIFUL SALON</a>-->
                <img src="../../img/logo resized.png" style="width: 80%;"/>
            </div>

            <div class="login-box-body" style="border-radius: 5px; box-shadow: 5px 10px 50px #ccc; border: 1px solid #ccc;">
                <h3 class="login-box-msg"><?php echo lang('login_information'); ?></h3>
                <span style="color:red;"><?php echo $message;?></span>

                <?php echo form_open('auth/login');?>
                    <div class="form-group has-feedback">
                        <?php echo form_input($identity);?>
                        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                    </div>
                    <div class="form-group has-feedback">

                        <?php echo form_input($password);?>
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    </div>
                    <div class="row">
                        <div class="col-xs-8">
                            <div class="checkbox icheck">
                                <label>
                                    <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"'); ?> <?php echo lang('remember_me'); ?>
                                </label>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <?php echo form_submit('submit', lang('login'), array('class' => 'btn btn-primary btn-block btn-flat'));?>
                        </div>
                    </div>
                <?php echo form_close();?>

<?php if ($auth_social_network == false): ?>
                <div class="social-auth-links text-center">
                    <p>- <?php echo lang('or_login'); ?> -</p>
                    <?php echo anchor('#', '<i class="fa fa-facebook"></i>' . lang('auth_sign_facebook'), array('class' => 'btn btn-block btn-social btn-facebook btn-flat')); ?>
                    <?php echo anchor('#', '<i class="fa fa-google-plus"></i>' . lang('auth_sign_google'), array('class' => 'btn btn-block btn-social btn-google btn-flat')); ?>
                </div>
<?php endif; ?>
<?php if ($forgot_password == TRUE): ?>
                <?php echo anchor('#', lang('forgot_password')); ?><br />
<?php endif; ?>
<?php if ($new_membership == TRUE): ?>
                <?php echo anchor('#', lang('new_member')); ?><br />
<?php endif; ?>
            </div>
