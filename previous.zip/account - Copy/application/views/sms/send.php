<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

<div class="content-wrapper">
	<section class="content-header">
		<?php echo $pagetitle; ?>
		<?php echo $breadcrumb; ?>
	</section>

	<section class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title"><?php echo lang('send bulk sms'); ?></h3>
					</div>

					<div class="box-body   col-md-offset-2">
<!--						--><?php //echo $message;?>

						<?php echo form_open(current_url(), array('class' => 'form-horizontal', 'id' => 'form-create_user')); ?>
						<div class="form-group">
							<?php echo lang('sender ID', 'sender', array('class' => 'col-sm-2 control-label',"align"=>"right"),":"); ?>
							<div class="col-sm-8 col-md-6 col-lg-5">
								<?php echo form_input($sender);?>
								<div class="progress progress-xxs margin-bottom-none" >
									<div id="display_progress" class="progress-bar" style="width: 0%"></div>
								</div>
								<span id="display_sender" class="label text-sm label-primary pull-right">11 character(s) left</span>

							</div>
						</div>
						<div class="form-group">
							<?php echo lang('recipient', 'recipient', array('class' => 'col-sm-2 control-label',"align"=>"right"),":"); ?>
							<div class="col-sm-5">
								<?php echo form_textarea($recipient);?>
								<span id="display_sender" class="label text-sm label-primary">11 character(s) left</span>

								<?php echo form_button(array('type' => 'submit', 'class' => 'btn btn-primary btn-flat', 'content' => lang('preview & send'))); ?>
							</div>
						</div>
						<div class="form-group">
							<?php echo lang('message', 'company', array('class' => 'col-sm-2 control-label',"align"=>"right"),":"); ?>
							<div class="col-sm-5 ">
								<?php echo form_textarea($message);?>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<div class="btn-group">
									<?php echo form_button(array('type' => 'submit', 'class' => 'btn btn-primary btn-flat', 'content' => lang('preview & send'))); ?>
									<?php echo form_button(array('type' => 'reset', 'class' => 'btn btn-warning btn-flat', 'content' => lang('send'))); ?>
									<?php echo anchor('admin/users', lang('save'), array('class' => 'btn btn-default btn-flat')); ?>
								</div>
							</div>
						</div>
						<?php echo form_close();?>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
