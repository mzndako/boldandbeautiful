<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends Public_Controller {

    public function __construct()
    {
        parent::__construct();
    }


	public function index()
	{
		if ( ! $this->ion_auth->logged_in())
		{
			redirect(base_url('auth/login'), 'refresh');
		}
		else
		{
			redirect(base_url('members/dashboard'), 'refresh');
		}
	}
}
