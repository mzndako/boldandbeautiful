<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        /* Load :: Common */
        $this->load->helper('number');
        $this->load->model('admin/dashboard_model');
    }


    function index(){

    }

    public function dashboard(){

        $this->page_title->push(lang('menu_dashboard'));
        $this->data['pagetitle'] = $this->page_title->show();

        /* Breadcrumbs */
        $this->data['breadcrumb'] = $this->breadcrumbs->show();

        /* Data */
        $this->data['count_users']       = $this->dashboard_model->get_count_record('members');
        $this->data['count_groups']      = $this->dashboard_model->get_count_record('groups');
        $this->data['disk_totalspace']   = 0;
        $this->data['disk_freespace']    = 0;
        $this->data['disk_usespace']     = 0;
        $this->data['disk_usepercent']   = 0;
        $this->data['memory_usage']      = 0;
        $this->data['memory_peak_usage'] = 0;
        $this->data['memory_usepercent'] = 0;

        /* TEST */
        $this->data['url_exist']    = is_url_exist('http://www.domprojects.com');

        /* Load Template */
        $this->template->admin_render('admin/dashboard/index', $this->data);
    }


    public function send(){
        rAccess("sendsms");

        $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

        // pass the user to the view
        $this->data['sender'] = array(
            'name'  => 'sender',
            'id'    => 'sender',
            'type'  => 'text',
            'class' => 'form-control',
            "onkeypress"=>"count_sender('sender','display_sender','display_progress')",
            "onkeyup"=>"count_sender('sender','display_sender','display_progress')",
           // 'value' => $this->form_validation->set_value('sender', $user->first_name)
        );
        $this->data['recipient'] = array(
            'name'  => 'recipient',
            'id'    => 'recipient',
            'type'  => 'textarea',
            'rows'=>"3",
            'class' => 'form-control',
            "onkeypress"=>"count_recipient(sender,recipient_display)",
            "onkeyup"=>"count_recipient(recipient,recipient_display)",
           // 'value' => $this->form_validation->set_value('last_name', $user->last_name)
        );
        $this->data['message'] = array(
            'name'  => 'company',
            'id'    => 'company',
            'type'  => 'textarea',
            'class' => 'form-control',
            "onkeypress"=>"count_message(message,message_display)",
            "onkeyup"=>"count_message(message,message_display)",
            //'value' => $this->form_validation->set_value('company', $user->company)
        );



        $this->page_title->push(lang('send bulk sms'));

        $this->data['pagetitle'] = $this->page_title->show();

        /* Breadcrumbs */
        $this->breadcrumbs->unshift(1, lang('menu_preferences'), 'admin/prefs');
        $this->data['breadcrumb'] = $this->breadcrumbs->show();

        /* Load Template */
        $this->template->admin_render('sms/send', $this->data);
    }



    public function staffs($param1 = '',$param2 = '', $param3 = ""){
        rAccess('view_staffs');

        if($param1 == 'load'){
            $options = array("required_all"=>true,"except"=>"");
            $this->data['update'] = -1;
            $this->data['onlyshow'] = false;
            if($param2 != ""){
                $options['values'] = (Array) d()->get_where("members",array("id"=>$param2))->row();
                $this->data['update'] = $options['values']['id'];
            }
            if($param3 != ""){
                $this->data['onlyshow'] = true;
            }
            $form = m()->get_form($options);
            $this->data['form'] = $form;
            $this->data['options'] = $options;
            return $this->template->modal_render('members/staffs_create', $this->data);
        }


       if ($param1 == 'create' || $param1 == 'update') {
           rAccess('manage_staffs');
           $form = m()->get_form();
            foreach($form as $col => $array){
                if($col == "access"){
                    $perm = is_array($this->input->post($col))?$this->input->post($col):array();
                    $data[$col] = implode(",",@$perm);
                    continue;
                }
                if($this->input->post($col) != null){
                    $data[$col] = $this->input->post($col);
                }
            }

           if($this->input->post("password") != null){
               $data['password'] = $this->ion_auth->hash_password($this->input->post("password"));
           }

            if($param1 == "create") {
                $data['isAdmin'] = 1;
                d()->insert('members', $data);
                $id = d()->insert_id();

                ss()->set_flashdata('flash_message', get_phrase('data_added_successfully'));
//			$this->email_model->account_opening_email('teacher', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
            }else{
                $id = $param2;
                d()->where("id",$id);
                d()->update("members",$data);
                s()->set_flashdata('flash_message', get_phrase('data_updated_successfully'));
            }
            m()->move_image("image","user",$id);
            redirect(base_url("members/staffs"), 'refresh');
        }



        if ($param1 == 'delete') {
            rAccess('delete_staff');
            d()->where('id', $param2);
            d()->delete('members');
            s()->set_flashdata('flash_message', get_phrase('data_deleted'));
            redirect(base_url("members/staffs"), 'refresh');
        }


        $this->page_title->push(lang('staff list'));
        $this->data['pagetitle'] = $this->page_title->show();

        $this->data['staffs'] = d()->get_where("members",array("isAdmin"=>1))->result_array();

        /* Breadcrumbs */
        $this->data['breadcrumb'] = $this->breadcrumbs->show();
        $this->template->admin_render('members/staffs', $this->data);
    }







    public function customers($param1 = '',$param2 = '', $param3 = ""){
        rAccess('view_customers');

        if($param1 == 'load'){
            $options = array("required_all"=>true,"except"=>"");
            $this->data['update'] = -1;
            $this->data['onlyshow'] = false;
            if($param2 != ""){
                $options['values'] = (Array) d()->get_where("members",array("id"=>$param2))->row();
                $this->data['update'] = $options['values']['id'];
            }
            if($param3 != ""){
                $this->data['onlyshow'] = true;
            }
            $form = m()->get_form($options);
            $this->data['form'] = $form;
            $this->data['options'] = $options;
            return $this->template->modal_render('members/customers_create', $this->data);
        }


       if ($param1 == 'create' || $param1 == 'update') {
               rAccess('manage_customers');

           $form = m()->get_form();
            foreach($form as $col => $array){
                if($col == "access"){
                    $perm = is_array($this->input->post($col))?$this->input->post($col):array();
                    $data[$col] = implode(",",@$perm);
                    continue;
                }
                if($this->input->post($col) != null){
                    $data[$col] = $this->input->post($col);
                }
            }

           if($this->input->post("password") != null){
               $data['password'] = $this->ion_auth->hash_password($this->input->post("password"));
           }

            if($param1 == "create") {
                $data['isAdmin'] = 0;
                d()->insert('members', $data);
                $id = d()->insert_id();

                s()->set_flashdata('flash_message', get_phrase('data_added_successfully'));
//			$this->email_model->account_opening_email('teacher', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
            }else{
                $id = $param2;
                d()->where("id",$id);
                d()->update("members",$data);
                s()->set_flashdata('flash_message', get_phrase('data_updated_successfully'));
            }
            m()->move_image("image","user",$id);
            redirect(base_url("members/customers"), 'refresh');
        }


        if ($param1 == 'delete') {
            rAccess('manage_customers');
            d()->where('id', $param2);
            d()->delete('members');
            s()->set_flashdata('flash_message', get_phrase('data_deleted'));
            redirect(base_url("members/customers"), 'refresh');
        }

        $this->page_title->push(lang('customers list'));
        $this->data['pagetitle'] = $this->page_title->show();

        $this->data['customers'] = d()->get_where("members",array("isAdmin"=>0))->result_array();

        /* Breadcrumbs */
        $this->data['breadcrumb'] = $this->breadcrumbs->show();
        $this->template->admin_render('members/customers', $this->data);
    }
}
