<div class="container">

    <center>
        <img src="uploads/logo2.png" width="120px"/>
        <h2>NUT ENDWELL MODEL SCIENCE SCHOOL</h2>
		<span>P.O BOX 2993, BESIDE PW COMPANY, CHANCHAGA, MINNA-NIGER STATE NIGERIA
		</span>
    </center>


<center>
	<h2 class="center-block">APPLICATION FORM</h2>
	<br>
	<div class="row">
		<div class="col-lg-offset-2 col-lg-4">
			<a href="?registration/register" class="btn btn-success">Register</a>
		</div>
		<div class="col-lg-4">
			<a data-toggle="collapse" href="#show" class="btn btn-danger">Continue Registration</a><br>
			<div id="show" class="collapse col-xm-4 form-group" style="margin-top: 8px;">
	<?php			echo form_open(base_url() . '?registration' , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data')); ?>
				<label class="col-xm-1 control-label">APP-ID:</label>
				<input class="col-xm-2" required type="text" name="app_id">
				<input type="submit" value="Continue" class="btn btn-warning col-xm-1" name="continue" >
				</form>
			</div>
		</div>
	</div>
</center>

</div>