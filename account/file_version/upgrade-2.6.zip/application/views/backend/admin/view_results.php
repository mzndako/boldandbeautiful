<hr />
<div class="row">
	<div class="col-md-12">
		<center>
			<?php
			echo form_open(base_url() . '?admin/view_results' , array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top',"method"=>"post"));
			?>
			<table border="0" cellspacing="0" cellpadding="0" class="table table-bordered">
				<tr>
					<td><?php echo get_phrase('select_session'); ?></td>
					<td><?php echo get_phrase('select_term'); ?></td>
					<td><?php echo get_phrase('select_class'); ?></td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>
						<select onchange="list_terms()" id="session" name="session_id" class="form-control"
						        data-validate="required"
						        data-message-required="<?php echo get_phrase('value_required'); ?>">
							<option value=""><?php echo get_phrase('select'); ?></option>
							<?php

							$sessions = $this->c_->get('year')->result_array();
							foreach ($sessions as $row2):
								?>
								<option <?php echo $session_id == $row2['year_id'] ? "selected" : ""; ?>
									value="<?php echo $row2['year_id']; ?>">
									<?php echo $row2['name'];; ?>
								</option>
								<?php
							endforeach;
							?>
						</select>
					</td>
					<td>
						<select id="term" name="term_id" class="form-control"
						        data-validate="required"
						        data-message-required="<?php echo get_phrase('value_required'); ?>">

						</select>
					</td>
					<td>
						<select name="class_id" class="form-control " id="class"
						        style="float:left;">
							<?php
							$classes = $this->c_->get('class')->result_array();
							foreach ($classes as $row):
								?>
								<option value="<?php echo $row['class_id']; ?>"
									<?php if ($class_id == $row['class_id']) echo 'selected'; ?>>
									<?php echo $row['name']; ?></option>
								<?php
							endforeach;
							?>
						</select>
					</td>



					<td>
						<input type="hidden" name="operation" value="selection"/>
						<input type="submit" value="<?php echo get_phrase('view_tabulation_sheet'); ?>"
						       class="btn btn-info"/>
					</td>
				</tr>
			</table>
			</form>
		</center>


	</div>
</div>

<?php if ($term_id != '' && $class_id != ''):?>
<br>
<div class="row">
	<div class="col-md-4"></div>
	<div class="col-md-4" style="text-align: center;">
		<div class="tile-stats tile-white tile-white-primary">
			<h3>
				<?php
//					$exam_name  = $this->db->get_where('exam' , array('exam_id' => $exam_id))->row()->name;
//					$class_name = $this->db->get_where('class' , array('class_id' => $class_id))->row()->name;
					echo get_phrase('tabulation_sheet');
				?>
			</h3>
<!--			<h4>--><?php //echo get_phrase('class') . ' ' . $class_name;?><!--</h4>-->
<!--			<h4>--><?php //echo $exam_name;?><!--</h4>-->
			<?php print date("m:i:s"); print " - ".microtime(true);

			ob_start();
			?>
		</div>
	</div>
	<div class="col-md-4"></div>
</div>


<hr />

<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered" id="table_exported">
			<thead>
				<tr>
				<td style="text-align: center;" rowspan="2">
					<?php echo get_phrase('students');?> <i class="entypo-down-thin"></i> | <?php echo get_phrase('subjects');?> <i class="entypo-right-thin"></i>
				</td>
				<?php
					$exams = $this->c_->get_where("exam",array("class_id"=>$class_id,"term_id"=>$term_id))->result_array();
					$examno = count($exams) + 1;
					$subjects = $this->c_->get_where('subject' , array('class_id' => $class_id))->result_array();
					foreach($subjects as $row):
				?>
					<td style="text-align: center;" colspan="<?php echo $examno;?>" class="result-tline"><?php echo
						$row['name'];
						?></td>
				<?php endforeach;?>
				<td style="text-align: center;" rowspan="2"><?php echo get_phrase('total');?></td>
				<td style="text-align: center;" rowspan="2"><?php echo get_phrase('total_(%)');?><i
						class="entypo-down-thin"></i></td>
					<td style="text-align: center;" rowspan="2"><?php echo get_phrase('B/F');?></td>
					<td style="text-align: center;" rowspan="2"><?php echo get_phrase('cum_total');?></td>
				<td style="text-align: center;" rowspan="2"><?php echo get_phrase('position');?><i class="entypo-down-thin"></i></td>
					<td style="text-align: center;" rowspan="2"><?php echo get_phrase('remark');?></td>
				</tr>

			<tr>

				<?php


				foreach($subjects as $row):
					$x = 0;
					foreach($exams as $exam):
						$x += $exam['mark'];
					?>
					<td style="text-align: center;" ><?php echo $exam['name']."<br>(".$exam['mark'].")";;?></td>
				<?php
					endforeach;
					?>
					<td style="text-align: center;" class="result-tline">Total<?php echo "<br>($x)";?></td>
					<?php
					endforeach;?>


			</tr>
			</thead>
			<tbody>
			<?php
				$previous_term = $this->c_->previous_term($term_id);
				$students = $this->c_->get_where('student' , array('class_id' => $class_id))->result_array();

			$my_mark = array();
			$my_mark = 	$this->c_->get_students_result($term_id,$class_id);

				foreach($students as $row):
			?>
				<tr>
					<td style="text-align: center;"><?php echo $this->c_->get_full_name($row);?></td>
				<?php
					$total_marks = 0;
					$total_grade_point = 0;
					foreach($subjects as $row2):
				?>

						<?php

							foreach($exams as $exam){
								print "<td style='text-align: center'>";
								print @$my_mark[$row['student_id']][$term_id][$row2['subject_id']][$exam['exam_id']];
								print "</td>";
							}
						print "<td style='text-align: center' class='result-tline''>";
						print @$my_mark[$row['student_id']][$term_id][$row2['subject_id']]['total'];
						print "</td>";


						?>

				<?php endforeach;?>
				<td style="text-align: center;"><?php echo $my_mark[$row['student_id']][$term_id]['total'];?></td>
					<!--					PERCENTAGE-->
				<td style="text-align: right;"><?php echo $my_mark[$row['student_id']][$term_id]['per_total'];
					?> %</td>
					<!--					BF-->
				<td style="text-align: center;"><?php echo
					isset($my_mark[$row['student_id']][$previous_term]['com_total'])?$my_mark[$row['student_id']][$previous_term]['com_total']:"--";?></td>


				<td style="text-align: center; color: red;"><?php echo
					$my_mark[$row['student_id']][$term_id]['com_total'];?></td>
<!--				<td style="text-align: center;">-->
<!--					--><?php //
//						$this->db->where('class_id' , $class_id);
//						$this->c_->get('subject');
//						$number_of_subjects = $this->db->count_all_results();
//						echo ($total_grade_point / $number_of_subjects);
//					?>
<!--				</td>-->
<!--					POSITION-->
					<td style="text-align: center;"><?php echo $my_mark[$row['student_id']]['com_term_'.$term_id];?></td>
					<td style="text-align: center;"></td>
				</tr>

			<?php endforeach;?>

			</tbody>
		</table>
		<?php
		ob_flush();
		print date("m:i:s"); print " - ".microtime(true);?>
		<center>
			<a href="<?php echo base_url();?>index.php?admin/tabulation_sheet_print_view/<?php echo $class_id;?>/<?php echo $term_id;?>"
				class="btn btn-primary" target="_blank">
				<?php echo get_phrase('print_tabulation_sheet');?>
			</a>
		</center>
	</div>
</div>
<?php endif;?>
<script type="text/javascript">
	jQuery(document).ready(function($)
	{


		var datatable = $("#table_exported").dataTable( {
			"iDisplayLength": 100,
			"sPaginationType": "bootstrap",
			"sDom": "<'row'<'col-xs-3 col-left'l><'col-xs-9 col-right'<'export-data'T>f>r>t<'row'<'col-xs-3 col-left'i><'col-xs-9 col-right'p>>",
			"oTableTools": {
			"aButtons": [

				{
					"sExtends": "xls",
					"mColumns": [0, 2, 3, 4]
				},
				{
					"sExtends": "pdf",
					"mColumns": [0, 2, 3, 4]
				},
				{
					"sExtends": "print",
					"fnSetText"	   : "Press 'esc' to return",
					"fnClick": function (nButton, oConfig) {
						datatable.fnSetColumnVis(1, false);
						datatable.fnSetColumnVis(5, false);

						this.fnPrint( true, oConfig );

						window.print();

						$(window).keyup(function(e) {
							if (e.which == 27) {
								datatable.fnSetColumnVis(1, true);
								datatable.fnSetColumnVis(5, true);
							}
						});
					},

				},
			]
		},

		} );

		$(".dataTables_wrapper select").select2({
			minimumResultsForSearch: -1
		});
	});
	<?php  $this->c_->print_list_terms($term_id); ?>
</script>
