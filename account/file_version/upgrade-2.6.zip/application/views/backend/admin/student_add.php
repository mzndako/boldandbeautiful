<?php
$update = -1;
if(is_numeric(@$param2)){
	$update = $param2;
}

$onlyshow = true;
if(isset($param3) && $param3 == "show"){
	$onlyshow = true;
}else{
	$onlyshow = false;
}

$options = array("required_all"=>false,"except"=>"");
if($update > -1){
	$this->db->where("student_id",$param2);
	$student = $this->c_->get("student")->row_array();

	$options['student'] = $student;
	$id = $student['student_id'];
}
$form = $this->c_->get_student_form($options);
$myform['Biodata'] = "myimage,surname,fname,mname,admission_no,birthday,sex,religion,class_id,phone,parent_id,email,password";
$myform['Address'] = "nationality,state,lga,permanent_address,country_of_origin,primary_language";
$myform['Relation/Guardian'] = "sponsor_name,sponsor_address,sponsor_phone,sponsor_relationship";

$myform['Referees']['Primary'] = "c1_name,c1_address1,c1_address2,c1_phone,c1_relationship";
$myform['Referees']['Secondary'] = "c2_name,c2_address1,c2_address2,c2_phone,c2_relationship";
//$myform['Primary Referees'] = "c1_name,c1_address1,c1_address2,c1_phone,c1_relationship";
//$myform['Secondary Referees'] = "c2_name,c2_address1,c2_address2,c2_phone,c2_relationship";
$myform['Previous School'] = "last_school,last_school_duration,last_school_reason";
$myform['Other Details'] = "hear_about_us,others";
?>
	<h2><?php
	if($update > -1){
		echo ucwords($student['surname'].", ".$student['fname']." ". $student['mname']);
	}else
		echo "Add Student";
?></h2>
	<ul class="nav nav-tabs bordered">
		<?php
		$active = "class='active'";
		foreach($myform as $header => $footer):
			$tag = str_replace(" ","",$header);
			$tag = str_replace("/","",$tag);
		?>
		<li <?php echo $active;?>><a data-toggle="tab" href="#<?php echo $tag;?>"><?php echo $header;?></a></li>
		<?php
			$active = "";
		endforeach;?>

	</ul>
<?php
$link = "create";
if($update > -1){
	$link = "update/$id/$student[class_id]";
}
echo form_open(base_url() . '?admin/student/'.$link , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data', 'id'=>'myform'));
?>
	<div class="tab-content">
		<?php


		$active = "in active";
			foreach($myform as $header => $footer):
				$tag = str_replace(" ","",$header);
				$tag = str_replace("/","",$tag);
		?>
		<div id="<?php echo $tag;?>" class="tab-pane fade <?php echo $active;?>">
			<?php
				if(is_array($footer)){
					echo '<ul class="nav nav-tabs bordered">';
					$act = "class='active'";
					foreach($footer as $h => $f){
						$tag = str_replace(" ","",$h);
						$tag = str_replace("/","",$tag);
						echo "
						<li $act><a data-toggle='tab' href='#$tag'>$h</a></li>
						";
						$act = '';
					}
					echo '</ul>';
				}else{
					echo '<h3>'.$header.'</h3>';
				}
			?>

				<div class="tab-content">
			<?php
			$loopf = array();
			if(is_array($footer)){
				$loopf = $footer;
			}else{
				$loopf["test"] = $footer;
			}
			$active2 = "in active";
			foreach($loopf as $h => $footer) {
				$tag = str_replace(" ","",$h);
				$tag = str_replace("/","",$tag);
				echo "<div id='$tag' class='tab-pane fade $active2'>";
				$footer = explode(",", $footer);
				foreach ($footer as $value) {
					if (!isset($form[$value])) {
						if ($value == "myimage") {
							$options = array("type" => "student", "id" => $update, "onlyshow" => $onlyshow);
							echo "<center>" . $this->c_->construct_image($options) . "</center>";
						}
						continue;
					}
					$col = $value;
					$array = $form[$value];
					$array['name'] = $col;
					$array['onlyshow'] = $onlyshow;
					$show = $array['type'] == "hidden" ? "style='display: none'" : "";
					?>

					<div class="form-group" <?php echo $show; ?>>
						<label class="control-label col-xs-3" for='<?php echo $col; ?>'><?php echo $array['label']; ?>:</label>

						<div class="col-xs-8">
							<?php echo $this->c_->create_input($array); ?>

						</div>
					</div>

				<?php }
				$active2 = "";
				echo '</div>';
			}
			$active = "";

			?>

				</div>
		</div>
		<?php endforeach;

		if(!$onlyshow):
		?>
			<center>
		<input type="submit" value="Save" name="save" class="btn btn-warning">
			</center>
		<?php endif; ?>
	</div>
</form>
