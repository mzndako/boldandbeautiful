<div class="sidebar-menu">
    <header class="logo-env" >

        <!-- logo -->
        <div class="logo" style="">
            <a href="<?php echo base_url(); ?>">
                <img src="<?php echo $this->c_->get_image_url('',-1,'logo');?>"  style="max-height:60px;"/>
            </a>
        </div>

        <!-- logo collapse icon -->
        <div class="sidebar-collapse" style="">
            <a href="#" class="sidebar-collapse-icon with-animation">

                <i class="entypo-menu"></i>
            </a>
        </div>

        <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
        <div class="sidebar-mobile-menu visible-xs">
            <a href="#" class="with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>
    </header>

    <div style=""></div>	
    <ul id="main-menu" class="">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


        <!-- DASHBOARD -->

        <li class="<?php if ($page_name == 'dashboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>?admin/dashboard">
                <i class="entypo-gauge"></i>
                <span><?php echo get_phrase('dashboard'); ?></span>
            </a>
        </li>

        <!-- STUDENT -->
        <?php if($s_-> hAccess("admit_student") | $s_-> hAccess("view_students")): ?>
        <li class="<?php
        if ($page_name == 'student_add' ||
                $page_name == 'student_bulk_add' ||
                $page_name == 'student_information' ||
                $page_name == 'student_marksheet')
            echo 'opened active has-sub';
        ?> ">
            <a href="#">
                <i class="fa fa-group"></i>
                <span><?php echo get_phrase('student'); ?></span>
            </a>
            <ul>
                <!-- STUDENT ADMISSION -->
                <?php if($s_-> hAccess("admit_student")): ?>
                <li class="<?php if ($page_name == 'student_add') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>?admin/student_add">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admit_student'); ?></span>
                    </a>
                </li>

                <!-- STUDENT BULK ADMISSION -->
                <li class="<?php if ($page_name == 'student_bulk_add') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>?admin/student_bulk_add">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('admit_bulk_student'); ?></span>
                    </a>
                </li>
                <?php endif; ?>

                <!-- STUDENT INFORMATION -->
                <?php if($s_-> hAccess("view_students")): ?>
                <li class="<?php if ($page_name == 'student_information' || $page_name == 'student_marksheet') echo 'opened active'; ?> ">
                    <a href="#">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('student_information'); ?></span>
                    </a>
                    <ul>
                        <?php
                        $data = array();
                        if($this->c_->isStudent()){
                            $student = $this->c_->get_student_info($login_id);
                            $data["class_id"] = $student['class_id'];
                        }elseif($this->c_->isTeacher()){
                            $data['teacher_id'] = $login_id;
                        }elseif($this->c_->isParent()){
                            $ids = $this->c_->get_all_student_for_parent($login_id);
                            $this->db->where_in("class_id",$ids);
                        }
                        $classes = $this->c_->get_where('class',$data)->result_array();

                        foreach ($classes as $row):

                            ?>
                            <li class="<?php if ($page_name == 'student_information' && $page_name == 'student_marksheet' && $class_id == $row['class_id']) echo 'active'; ?>">
                                <a href="<?php echo base_url(); ?>?admin/student_information/<?php echo $row['class_id']; ?>">
                                    <span><?php echo get_phrase('class'); ?> <?php echo $row['name']; ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </li>
                <?php endif; ?>

            </ul>
        </li>
        <?php endif; ?>

        <?php if($s_-> hAccess("view_teachers")): ?>
        <!-- TEACHER -->
        <li class="<?php if ($page_name == 'teacher') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>?admin/teacher">
                <i class="entypo-users"></i>
                <span><?php echo get_phrase('staffs'); ?></span>
            </a>
        </li>
        <?php endif; ?>


        <!-- PARENTS -->
        <?php if($s_-> hAccess("view_parents")): ?>
        <li class="<?php if ($page_name == 'parent') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>?admin/parent">
                <i class="entypo-user"></i>
                <span><?php echo get_phrase('parents'); ?></span>
            </a>
        </li>
        <?php endif; ?>

        <!-- CLASS -->
        <?php if($s_-> hAccess("view_classes")): ?>
        <li class="<?php
        if ($page_name == 'class' ||
                $page_name == 'section')
            echo 'opened active';
        ?> ">
            <a href="#">
                <i class="entypo-flow-tree"></i>
                <span><?php echo get_phrase('class'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'class') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>?admin/classes">
                        <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_classes'); ?></span>
                    </a>
                </li>
<!--                <li class="--><?php //if ($page_name == 'section') echo 'active'; ?><!-- ">-->
<!--                    <a href="--><?php //echo base_url(); ?><!--?admin/section">-->
<!--                        <span><i class="entypo-dot"></i> --><?php //echo get_phrase('manage_sections'); ?><!--</span>-->
<!--                    </a>-->
<!--                </li>-->
            </ul>
        </li>
        <?php endif; ?>

        <!-- SUBJECT -->
        <?php if($s_-> hAccess("view_subjects")): ?>
        <li class="<?php if ($page_name == 'subject') echo 'opened active'; ?> ">
            <a href="#">
                <i class="entypo-docs"></i>
                <span><?php echo get_phrase('subject'); ?></span>
            </a>
            <ul>
                <?php
                $data = array();
                if($this->c_->isStudent()){
                    $student = $this->c_->get_student_info($login_id);
                    $data["class_id"] = $student['class_id'];
                }elseif($this->c_->isTeacher()){
                    $data['teacher_id'] = $login_id;
                }elseif($this->c_->isParent()){
                    $ids = $this->c_->get_all_student_for_parent($login_id);
                    $this->db->where_in("class_id",$ids);
                }
                $classes = $this->c_->get_where('class',$data)->result_array();
                foreach ($classes as $row):
                    ?>
                    <li class="<?php if ($page_name == 'subject' && $class_id == $row['class_id']) echo 'active'; ?>">
                        <a href="<?php echo base_url(); ?>?admin/subject/<?php echo $row['class_id']; ?>">
                            <span><?php echo get_phrase('class'); ?> <?php echo $row['name']; ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </li>
        <?php endif;?>

        <!-- CLASS ROUTINE -->
        <?php if($s_->hAccess('view_routines')): ?>
            <li class="<?php if ($page_name == 'class_routine') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/class_routine">
                    <i class="entypo-target"></i>
                    <span><?php echo get_phrase('class_routine'); ?></span>
                </a>
            </li>
        <?php endif; ?>



        <!-- DAILY ATTENDANCE -->
        <?php if($s_->hAccess('view_attendances')): ?>
            <li class="<?php if ($page_name == 'manage_attendance') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/manage_attendance/<?php echo date("d/m/Y"); ?>">
                    <i class="entypo-chart-area"></i>
                    <span><?php echo get_phrase('daily_attendance'); ?></span>
                </a>

            </li>
        <?php endif; ?>



        <!-- EXAMS -->

            <?php if($s_->hAccess('view_exams') ||
                $s_->hAccess('view_grades') ||
                $s_->hAccess('manage_marks') ||
                $s_->hAccess('send_marks') ||
                $s_->hAccess('view_marks') ||
                $s_->hAccess('view_results')): ?>
                <li class="<?php
                if ($page_name == 'exam' ||
                    $page_name == 'grade' ||
                    $page_name == 'marks' ||
                    $page_name == 'exam_marks_sms' ||
                    $page_name == 'tabulation_sheet')
                    echo 'opened active';
                ?> ">
                    <a href="#">
                        <i class="entypo-graduation-cap"></i>
                        <span><?php echo get_phrase('exam'); ?></span>
                    </a>
                    <ul>
                        <?php if($s_->hAccess('view_exams')): ?>
                            <li class="<?php if ($page_name == 'exam') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/exam">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_list'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($s_->hAccess('view_grades')): ?>
                            <li class="<?php if ($page_name == 'grade') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/grade">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('exam_grades'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($s_->hAccess('manage_marks')): ?>
                            <li class="<?php if ($page_name == 'marks') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/marks">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_marks'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>


                        <?php if($s_->hAccess('send_marks')): ?>
                            <li class="<?php if ($page_name == 'exam_marks_sms') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/exam_marks_sms">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('send_marks_by_sms'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>


                        <?php if($s_->hAccess('view_marks')): ?>
                            <li class="<?php if ($page_name == 'tabulation_sheet') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/tabulation_sheet">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('tabulation_sheet'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>


                        <?php if($s_->hAccess('view_results')): ?>
                            <li class="<?php if ($page_name == 'view_results') echo 'active'; ?> ">
                                <a href="<?php echo base_url(); ?>?admin/view_results">
                                    <span><i class="entypo-dot"></i> <?php echo get_phrase('view_results'); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>
        <?php endif; ?>




        <?php if($s_->hAccess('manage_cbt')): ?>
            <li class="<?php if ($page_name == 'manage_cbt') echo 'active'; ?> ">
                <a target="_blank" href="<?php echo base_url(); ?>?admin/launch_cbt">
                    <i class="entypo-chart-area"></i>
                    <span><?php echo get_phrase('launch_cbt'); ?></span>
                </a>

            </li>
        <?php endif; ?>


<!--<!--         PAYMENT -->-->
<!--         <li class="--><?php //if ($page_name == 'invoice') echo 'active'; ?><!-- ">-->
<!--            <a href="--><?php ////echo base_url(); ?><!--?admin/invoice">-->
<!--                <i class="entypo-credit-card"></i>-->
<!--                <span>--><?php ////echo get_phrase('payment'); ?><!--</span>-->
<!--            </a>-->
<!--        </li>-->

        <!-- ACCOUNTING -->
        <?php if($s_->hAccess('create_invoice') ||
            $s_->hAccess('view_invoices') ||
            $s_->hAccess('view_expenses') ||
            $s_->hAccess('manage_expenses')):  ?>
            <li class="<?php
            if ($page_name == 'income' ||
                $page_name == 'expense' ||
                $page_name == 'expense_category' ||
                $page_name == 'student_payment')
                echo 'opened active';
            ?> ">
                <a href="#">
                    <i class="entypo-suitcase"></i>
                    <span><?php echo get_phrase('accounting'); ?></span>
                </a>
                <ul>
                    <?php if($s_->hAccess('create_invoice')): ?>
                        <li class="<?php if ($page_name == 'student_payment') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>?admin/student_payment">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('create_student_payment'); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>



                    <?php if($s_->hAccess('view_invoices')): ?>
                        <li class="<?php if ($page_name == 'income') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>?admin/income">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('student_payments'); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if($s_->hAccess('view_expenses')): ?>
                        <li class="<?php if ($page_name == 'expense') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>?admin/expense">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('expense'); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>



                    <?php if($s_->hAccess('manage_expenses')): ?>
                        <li class="<?php if ($page_name == 'expense_category') echo 'active'; ?> ">
                            <a href="<?php echo base_url(); ?>?admin/expense_category">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('expense_category'); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>


                </ul>
            </li>
        <?php endif; ?>




        <!-- LIBRARY -->
        <?php if($s_->hAccess('view_books')): ?>
            <li class="<?php if ($page_name == 'book') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/book">
                    <i class="entypo-book"></i>
                    <span><?php echo get_phrase('library'); ?></span>
                </a>
            </li>
        <?php endif; ?>




        <!-- TRANSPORT -->
        <?php if($s_->hAccess('view_transports')): ?>
            <li class="<?php if ($page_name == 'transport') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/transport">
                    <i class="entypo-location"></i>
                    <span><?php echo get_phrase('transport'); ?></span>
                </a>
            </li>
        <?php endif; ?>




        <!-- DORMITORY -->
       <?php if($s_->hAccess('view_dormitories')): ?>
           <li class="<?php if ($page_name == 'dormitory') echo 'active'; ?> ">
               <a href="<?php echo base_url(); ?>?admin/dormitory">
                   <i class="entypo-home"></i>
                   <span><?php echo get_phrase('dormitory'); ?></span>
               </a>
           </li>
        <?php endif; ?>




        <!-- NOTICEBOARD -->
        <?php if($s_->hAccess('view_board')): ?>
            <li class="<?php if ($page_name == 'noticeboard') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/noticeboard">
                    <i class="entypo-doc-text-inv"></i>
                    <span><?php echo get_phrase('noticeboard'); ?></span>
                </a>
            </li>
        <?php endif; ?>



        <!-- MESSAGE -->
        <?php if($s_->hAccess('view_messages')): ?>
            <li class="<?php if ($page_name == 'message') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>?admin/message">
                    <i class="entypo-mail"></i>
                    <span><?php echo get_phrase('message'); ?></span>
                </a>
            </li>
        <?php endif; ?>



        <!-- SETTINGS -->
       <?php if($s_->hAccess('manage_settings') ||
           $s_->hAccess('manage_sms') ||
           $s_->hAccess('manage_languages') ||
           $s_->hAccess('manage_segment') ||
           $s_->hAccess('manage_session') ||
           $s_->hAccess('view_permissions')): ?>
           <li class="<?php
           if ($page_name == 'system_settings' ||
               $page_name == 'manage_language' ||
               $page_name == 'segment' ||
               $page_name == 'session' ||
               $page_name == 'security' ||
               $page_name == 'sms_settings')
               echo 'opened active';
           ?> ">
               <a href="#">
                   <i class="entypo-lifebuoy"></i>
                   <span><?php echo get_phrase('settings'); ?></span>
               </a>
               <ul>
                   <?php if($s_->hAccess('manage_settings')): ?>
                       <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/system_settings">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('general_settings'); ?></span>
                           </a>
                       </li>
               <?php endif; ?>


                   <?php if($s_->hAccess('manage_sms')): ?>
                       <li class="<?php if ($page_name == 'sms_settings') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/sms_settings">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('sms_settings'); ?></span>
                           </a>
                       </li>
                   <?php endif; ?>


                   <?php if($s_->hAccess('manage_languages')): ?>
                       <li class="<?php if ($page_name == 'manage_language') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/manage_language">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('language_settings'); ?></span>
                           </a>
                       </li>
                   <?php endif; ?>



                   <?php if($s_->hAccess('manage_segment')): ?>
                       <li class="<?php if ($page_name == 'segment') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/segment">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('manage_segment'); ?></span>
                           </a>
                       </li>
                   <?php endif; ?>



                   <?php if($s_->hAccess('manage_session')): ?>
                       <li class="<?php if ($page_name == 'session') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/session">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('school_session'); ?></span>
                           </a>
                       </li>
                   <?php endif; ?>



                   <?php if($s_->hAccess('view_permissions')): ?>
                       <li class="<?php if ($page_name == 'security') echo 'active'; ?> ">
                           <a href="<?php echo base_url(); ?>?admin/security">
                               <span><i class="entypo-dot"></i> <?php echo get_phrase('security'); ?></span>
                           </a>
                       </li>
                   <?php endif; ?>


               </ul>
           </li>
        <?php endif; ?>





        <!-- ACCOUNT -->
        <li class="<?php if ($page_name == 'manage_profile') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>?admin/manage_profile">
                <i class="entypo-lock"></i>
                <span><?php echo get_phrase('account'); ?></span>
            </a>
        </li>

    </ul>

</div>