<?php
$update = -1;
if(is_numeric(@$param2)){
	$update = $param2;
}

$onlyshow = true;
if(isset($param3) && $param3 == "show"){
	$onlyshow = true;
}else{
	$onlyshow = false;
}

$options = array("required_all"=>false,"except"=>"");
if($update > -1){
	$this->db->where("teacher_id",$param2);
	$student = $this->c_->get("teacher")->row_array();

	$options['teacher'] = $student;
	$id = $student['teacher_id'];
}
$form = $this->c_->get_teacher_form($options);
$myform['Biodata'] = "myimage,surname,fname,mname,birthday,sex,phone,religion,profession,is_academic,email,password";
$myform['Address'] = "nationality,state_of_origin,lga,address";
$myform['Next of Kin'] = "next_of_kin_name,next_of_kin_address,next_of_kin_phone";
$myform['Employment'] = "date_of_employment,type_of_employment,job_title,year_of_experience,status,line_manager,highest_qualification";
$myform['Documents'] = "!signature,!highest_qualification,access";
?>
<h2><?php
	if($update > -1){
		echo ucwords($student['surname'].", ".$student['fname']." ". $student['mname']);
	}else
		echo "Add Teacher";
	?></h2>
<ul class="nav nav-tabs bordered">
	<?php
	$active = "class='active'";
	foreach($myform as $header => $footer):
		$tag = str_replace(" ","",$header);
		$tag = str_replace("/","",$tag);
		?>
		<li <?php echo $active;?>><a data-toggle="tab" href="#<?php echo $tag;?>"><?php echo $header;?></a></li>
		<?php
		$active = "";
	endforeach;?>

</ul>
<?php
$link = "create";
if($update > -1){
	$link = "update/$id";
}
echo form_open(base_url() . '?admin/teacher/'.$link , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data', 'id'=>'myform'));
?>
<div class="tab-content">
	<?php


	$active = "in active";
	foreach($myform as $header => $footer):
		$tag = str_replace(" ","",$header);
		$tag = str_replace("/","",$tag);
		?>
		<div id="<?php echo $tag;?>" class="tab-pane fade <?php echo $active;?>">
			<?php
			if(is_array($footer)){
				echo '<ul class="nav nav-tabs bordered">';
				$act = "class='active'";
				foreach($footer as $h => $f){
					$tag = str_replace(" ","",$h);
					$tag = str_replace("/","",$tag);
					echo "
						<li $act><a data-toggle='tab' href='#$tag'>$h</a></li>
						";
					$act = '';
				}
				echo '</ul>';
			}else{
				echo '<h3>'.$header.'</h3>';
			}
			?>

			<div class="tab-content">
				<?php
				$loopf = array();
				if(is_array($footer)){
					$loopf = $footer;
				}else{
					$loopf["test"] = $footer;
				}
				$active2 = "in active";
				foreach($loopf as $h => $footer) {
					$tag = str_replace(" ","",$h);
					$tag = str_replace("/","",$tag);
					echo "<div id='$tag' class='tab-pane fade $active2'>";
					$footer = explode(",", $footer);
					foreach ($footer as $value) {
						if (!isset($form[$value]) && strpos($value,"!") === false) {
							if ($value == "myimage") {
								$options = array("type" => "teacher", "id" => $update, "onlyshow" => $onlyshow);
								echo "<center>" . $this->c_->construct_image($options) . "</center>";
							}
							continue;
						}
						if(strpos($value,"!") !== false){
							$value = substr($value,1);
							$col = $value;
							$array['name'] = $value;
							$array['label'] = ucwords(str_replace("_"," ",$value));
							$array['id_prefix'] = $value;
							$array['type_'] = "teacher";
							$array['type'] = "image";
							$array['onlyshow'] = $onlyshow;
							$array['id'] = $update;
						}else {
							$col = $value;
							$array = $form[$value];
							$array['onlyshow'] = $onlyshow;
							$show = $array['type'] == "hidden" ? "style='display: none'" : "";
						}
						?>

						<div class="form-group" <?php echo $show; ?>>
							<label class="control-label col-xs-3" for='<?php echo $col; ?>'><?php echo $array['label']; ?>:</label>

							<div class="col-xs-8">
								<?php echo $this->c_->create_input($array); ?>

							</div>
						</div>

					<?php }
					$active2 = "";
					echo '</div>';
				}
				$active = "";

				?>

			</div>
		</div>
	<?php endforeach;

	if(!$onlyshow):
		?>
		<center>
			<input type="submit" value="Save" name="save" class="btn btn-warning">
		</center>
	<?php endif; ?>
</div>
</form>
