<?php
$edit_data		=	$this->c_->get_where('exam' , array('exam_id' => $param2) )->result_array();
foreach ( $edit_data as $row):
?>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title" >
            		<i class="entypo-plus-circled"></i>
					<?php echo get_phrase('edit_student');?>
            	</div>
            </div>
			<div class="panel-body">
				
                <?php echo form_open(base_url() . 'index.php?admin/exam/do_update/'.$row['exam_id']."/".$param3, array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top'));?>
            <div class="padded">
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('name');?></label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="name" value="<?php echo $row['name'];?>" data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
                    <div class="col-sm-5">
                        <select name="class_id" class="form-control selectboxit" multiple="multiple" data-validate="required" data-placeholder="Select Class" data-message-required="<?php echo get_phrase
                        ('value_required');?>">
                            <option value=""><?php echo get_phrase('select_class');?></option>
                            <?php
                            $terms = $this->c_->get('class')->result_array();
                            foreach($terms as $row2):
                                ?>
                                <option <?php echo $row['class_id'] == $row2['class_id']?"selected":"";?> value="<?php echo $row2['class_id'];?>" >
                                    <?php echo $this->c_ ->get_class_name($row2['class_id']);?>
                                </option>
                                <?php
                            endforeach;
                            ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('term');?></label>
                    <div class="col-sm-5">
                        <select name="term_id" class="form-control selectboxit" data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>">
                            <option value=""><?php echo get_phrase('select');?></option>
                            <?php
                            $current_term = $row['term_id'];
                            $terms = $this->c_->get('term')->result_array();
                            foreach($terms as $row2):
                                ?>
                                <option <?php echo $current_term == $row2['term_id']?"selected":"";?> value="<?php echo $row2['term_id'];?>" <?php echo $row2['term_id'];?>>
                                    <?php echo $row2['name'];?>
                                </option>
                                <?php
                            endforeach;
                            ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('mark');?></label>
                    <div class="col-sm-5">
                        <input type="number" class="form-control" name="mark" data-validate="required" value="<?php echo $row['mark'];?>" data-message-required="<?php echo get_phrase('value_required');?>"/>
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('date');?></label>
                    <div class="col-sm-5">
                        <input type="text" class="datepicker form-control" name="date" value="<?php echo $row['date'];?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label"><?php echo get_phrase('comment');?></label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="comment" value="<?php echo $row['comment'];?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-5">
                      <button type="submit" class="btn btn-info"><?php echo get_phrase('edit_exam');?></button>
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>

<?php
endforeach;
?>





