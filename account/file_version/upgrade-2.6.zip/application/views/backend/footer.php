<!-- Footer -->
<footer class="main">
	&copy; 2016 <strong>SCHOOL MANAGEMENT SOFTWARE</strong>.
    Developed by 
	<a href="http://linkingsms.com"
    	target="_blank">LinkingSMS Solution</a>
</footer>
