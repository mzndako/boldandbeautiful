<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Crud_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function clear_cache() {
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
    }

    function get_type_name_by_id($type, $type_id = '', $field = 'name') {
          return $this->get_where($type, array($type . '_id' => $type_id        ))->row()->$field;
    }

    function get_parent_info($parent_id) {
        $query = $this->get_where('parent', array('parent_id' => $parent_id));
        return $query->row_array();
    }

    function get_all_students_for_parent($parent_id,$what = "class_id"){
        $students = $this->get_where("student",array("parent_id"=>$parent_id))->result_array();
        $ids = array();
        foreach($students as $row){
            $ids[] = $row[$what];
        }
        return $ids;
    }

    function get_ids($table,$where,$what){
        $students = $this->get_where($table,$where)->result_array();
        $ids = array();
        foreach($students as $row){
            $ids[] = $row[$what];
        }
        return $ids;
    }
    ////////STUDENT/////////////

    function get_students($class_id) {
        $query = $this->get_where('student', array('class_id' => $class_id));
        return $query->result_array();
    }

    function get_student_info($student_id) {
        $query = $this->get_where('student', array('student_id' => $student_id));
        return $query->row_array();
    }

    /////////TEACHER/////////////
    function get_teachers() {
        $query = $this->get('teacher');
        return $query->result_array();
    }

    function get_teachers_by($academic = true) {
        $query = $this->get_where('teacher',array(""));
        return $query->result_array();
    }

    function get_teacher_name($teacher_id) {
        $query = $this->get_where('teacher', array('teacher_id' => $teacher_id));
        $res = $query->result_array();
        foreach ($res as $row)
            return $this->get_full_name($row);
    }

    function get_teacher_info($teacher_id) {
        $query = $this->get_where('teacher', array('teacher_id' => $teacher_id));
        return $query->result_array();
    }

    //////////SUBJECT/////////////
    function get_subjects() {
        $query = $this->get('subject');
        return $query->result_array();
    }

    function get_subject_info($subject_id) {
        $query = $this->get_where('subject', array('subject_id' => $subject_id));
        return $query->result_array();
    }

    function get_subjects_by_class($class_id) {
        $query = $this->get_where('subject', array('class_id' => $class_id));
        return $query->result_array();
    }

    function get_subject_name_by_id($subject_id) {
        $query = $this->get_where('subject', array('subject_id' => $subject_id))->row();
        return $query->name;
    }

    ////////////CLASS///////////
    function get_class_name($class_id) {
        $query = $this->get_where('class', array('class_id' => $class_id));
        $res = $query->result_array();
        foreach ($res as $row)
            return $row['name'];
    }

    function get_class_name_numeric($class_id) {
        $query = $this->get_where('class', array('class_id' => $class_id));
        $res = $query->result_array();
        foreach ($res as $row)
            return $row['name_numeric'];
    }

    function get_classes() {
        $query = $this->get_where('class',array('school_id'=>$GLOBALS['SCHOOL_ID'],"division_id"=>DIVISION_ID));
        return $query->result_array();
    }

    function get_class_info($class_id) {
        $query = $this->get_where('class', array('class_id' => $class_id));
        return $query->result_array();
    }

    //////////EXAMS/////////////
    function get_exams() {
        $query = $this->get('exam');
        return $query->result_array();
    }

    function get_exam_info($exam_id) {
        $query = $this->get_where('exam', array('exam_id' => $exam_id));
        return $query->result_array();
    }

    function get_term($term_id) {
        $query = $this->where('term_id',$term_id);
        return $this->get("term");
    }

    //////////GRADES/////////////
    function get_grades() {
        $query = $this->get('grade');
        return $query->result_array();
    }

    function get_grade_info($grade_id) {
        $query = $this->get_where('grade', array('grade_id' => $grade_id));
        return $query->result_array();
    }

    function get_obtained_marks( $exam_id , $class_id , $subject_id , $student_id) {
        $marks = $this->get_where('mark' , array(
                                    'subject_id' => $subject_id,
                                        'exam_id' => $exam_id,
                                            'class_id' => $class_id,
                                                'student_id' => $student_id))->result_array();
                                        
        foreach ($marks as $row) {
            echo $row['mark_obtained'];
        }
    }

    function get_highest_marks( $exam_id , $class_id , $subject_id ) {
        $this->db->where('exam_id' , $exam_id);
        $this->db->where('class_id' , $class_id);
        $this->db->where('subject_id' , $subject_id);
        $this->db->select_max('mark_obtained');
        $highest_marks = $this->get('mark')->result_array();
        foreach($highest_marks as $row) {
            echo $row['mark_obtained'];
        }
    }

    function get_grade($mark_obtained) {
        $query = $this->get('grade');
        $grades = $query->result_array();
        foreach ($grades as $row) {
            if ($mark_obtained >= $row['mark_from'] && $mark_obtained <= $row['mark_upto'])
                return $row;
        }
    }

    function create_log($data) {
        $data['timestamp'] = strtotime(date('Y-m-d') . ' ' . date('H:i:s'));
        $data['ip'] = $_SERVER["REMOTE_ADDR"];
        $location = new SimpleXMLElement(file_get_contents('http://freegeoip.net/xml/' . $_SERVER["REMOTE_ADDR"]));
        $data['location'] = $location->City . ' , ' . $location->CountryName;
        $this->db->insert('log', $data);
    }

    function get_system_settings() {
        $query = $this->get('settings');
        return $query->result_array();
    }

    ////////BACKUP RESTORE/////////
    function create_backup($type) {
        $this->load->dbutil();


        $options = array(
            'format' => 'txt', // gzip, zip, txt
            'add_drop' => TRUE, // Whether to add DROP TABLE statements to backup file
            'add_insert' => TRUE, // Whether to add INSERT data to backup file
            'newline' => "\n"               // Newline character used in backup file
        );


        if ($type == 'all') {
            $tables = array('');
            $file_name = 'system_backup';
        } else {
            $tables = array('tables' => array($type));
            $file_name = 'backup_' . $type;
        }

        $backup = & $this->dbutil->backup(array_merge($options, $tables));


        $this->load->helper('download');
        force_download($file_name . '.sql', $backup);
    }

    /////////RESTORE TOTAL DB/ DB TABLE FROM UPLOADED BACKUP SQL FILE//////////
    function restore_backup() {
        move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/backup.sql');
        $this->load->dbutil();


        $prefs = array(
            'filepath' => 'uploads/backup.sql',
            'delete_after_upload' => TRUE,
            'delimiter' => ';'
        );
        $restore = & $this->dbutil->restore($prefs);
        unlink($prefs['filepath']);
    }

    /////////DELETE DATA FROM TABLES///////////////
    function truncate($type) {
        if ($type == 'all') {
            $this->db->truncate('student');
            $this->db->truncate('mark');
            $this->db->truncate('teacher');
            $this->db->truncate('subject');
            $this->db->truncate('class');
            $this->db->truncate('exam');
            $this->db->truncate('grade');
        } else {
            $this->db->truncate($type);
        }
    }

    function get_image_path($type){
        $x = $type == ""?"/":"/$type/";
        return "uploads/SCHOOL_".$GLOBALS['SCHOOL_ID'].$x;
    }

    function get_file_name($type,$id,$id_prefix = null){
        if($id_prefix == null || $id_prefix == ""){
            $id = $type."_".$id;
        }else
            $id = $id_prefix."_".$id;
        return $id.".jpg";
    }
    ////////IMAGE URL//////////
    function get_image_url($type = '', $id = '',$id_prefix = null) {

        $path = $this->get_image_path($type);
        $file = $this->get_file_name($type,$id,$id_prefix);

        $image = $path.$file;
        if (file_exists($image))
            $image_url = base_url() . $image;
        else {
            if($type == "") $type = "logo";
            $image_url = base_url() . 'uploads/SCHOOLS/' . $type . ".jpg";
        }

        return $image_url;
    }

    function move_image($source,$type,$id,$id_prefix=null){
        $path = $this->get_image_path($type);
        if(!is_dir($path)){
            mkdir($path, 0777, true);
        }
        $file = $this->get_file_name($type,$id,$id_prefix);
        return move_uploaded_file($_FILES[$source]['tmp_name'], $path.$file);
    }
    function construct_image($options){
        $type = isset($options['type'])?$options['type']:"student";
        $id = isset($options['id'])?$options['id']:-1;
        $id_prefix = isset($options['id_prefix'])?$options['id_prefix']:null;
        $onlyshow = isset($options['onlyshow'])?$options['onlyshow']:false;
        $name = isset($options['name'])?$options['name']:"image";
        $image_link = $this->get_image_url($type,$id,$id_prefix);
        if($onlyshow){
            return '
            <div>
            <a href="'.$image_link.'" title="Click to View" target="_blank"><img style="width: 100px; height: 100px;"
            src="'.$image_link.'"
            alt="'.$type.'"></a>
            </div>
            ';
        }
        return '
        <div class="fileinput fileinput-new" data-provides="fileinput" >
								<div data-validate=required data-message-required=Required class="fileinput-new thumbnail" style="width: 100px; height: 100px;" data-trigger="fileinput">
									<img src="'.$image_link.'" alt="...">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
								<div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="'.$name.'" accept="image/*">
									</span>
									<a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
								</div>
							</div>

        ';
    }

    ////////STUDY MATERIAL//////////
    function save_study_material_info()
    {
        $data['timestamp']      = strtotime($this->input->post('timestamp'));
        $data['title'] 		= $this->input->post('title');
        $data['description']    = $this->input->post('description');
        $data['file_name'] 	= $_FILES["file_name"]["name"];
        $data['file_type'] 	= $this->input->post('file_type');
        $data['class_id'] 	= $this->input->post('class_id');
        
        $this->db->insert('document',$data);
        
        $document_id            = $this->db->insert_id();
        move_uploaded_file($_FILES["file_name"]["tmp_name"], "uploads/document/" . $_FILES["file_name"]["name"]);
    }
    
    function select_study_material_info()
    {
        $this->db->order_by("timestamp", "desc");
        return $this->get('document')->result_array();
    }
    
    function select_study_material_info_for_student()
    {
        $student_id = $this->session->userdata('student_id');
        $class_id   = $this->get_where('student', array('student_id' => $student_id))->row()->class_id;
        $this->db->order_by("timestamp", "desc");
        return $this->get_where('document', array('class_id' => $class_id))->result_array();
    }
    
    function update_study_material_info($document_id)
    {
        $data['timestamp']      = strtotime($this->input->post('timestamp'));
        $data['title'] 		= $this->input->post('title');
        $data['description']    = $this->input->post('description');
        $data['class_id'] 	= $this->input->post('class_id');
        
        $this->db->where('document_id',$document_id);
        $this->db->update('document',$data);
    }
    
    function delete_study_material_info($document_id)
    {
        $this->db->where('document_id',$document_id);
        $this->db->delete('document');
    }
    
    ////////private message//////
    function send_new_private_message() {
        $message    = $this->input->post('message');
        $timestamp  = strtotime(date("Y-m-d H:i:s"));

        $reciever   = $this->input->post('reciever');
        $sender     = $this->session->userdata('login_type') . '-' . $this->session->userdata('login_user_id');

        //check if the thread between those 2 users exists, if not create new thread
        $num1 = $this->get_where('message_thread', array('sender' => $sender, 'reciever' => $reciever))->num_rows();
        $num2 = $this->get_where('message_thread', array('sender' => $reciever, 'reciever' => $sender))->num_rows();

        if ($num1 == 0 && $num2 == 0) {
            $message_thread_code                        = substr(md5(rand(100000000, 20000000000)), 0, 15);
            $data_message_thread['message_thread_code'] = $message_thread_code;
            $data_message_thread['sender']              = $sender;
            $data_message_thread['reciever']            = $reciever;
            $this->db->insert('message_thread', $data_message_thread);
        }
        if ($num1 > 0)
            $message_thread_code = $this->get_where('message_thread', array('sender' => $sender, 'reciever' => $reciever))->row()->message_thread_code;
        if ($num2 > 0)
            $message_thread_code = $this->get_where('message_thread', array('sender' => $reciever, 'reciever' => $sender))->row()->message_thread_code;


        $data_message['message_thread_code']    = $message_thread_code;
        $data_message['message']                = $message;
        $data_message['sender']                 = $sender;
        $data_message['timestamp']              = $timestamp;
        $this->db->insert('message', $data_message);

        // notify email to email reciever
        //$this->email_model->notify_email('new_message_notification', $this->db->insert_id());

        return $message_thread_code;
    }

    function send_reply_message($message_thread_code) {
        $message    = $this->input->post('message');
        $timestamp  = strtotime(date("Y-m-d H:i:s"));
        $sender     = $this->session->userdata('login_type') . '-' . $this->session->userdata('login_user_id');


        $data_message['message_thread_code']    = $message_thread_code;
        $data_message['message']                = $message;
        $data_message['sender']                 = $sender;
        $data_message['timestamp']              = $timestamp;
        $this->db->insert('message', $data_message);

        // notify email to email reciever
        //$this->email_model->notify_email('new_message_notification', $this->db->insert_id());
    }

    function mark_thread_messages_read($message_thread_code) {
        // mark read only the oponnent messages of this thread, not currently logged in user's sent messages
        $current_user = $this->session->userdata('login_type') . '-' . $this->session->userdata('login_user_id');
        $this->db->where('sender !=', $current_user);
        $this->db->where('message_thread_code', $message_thread_code);
        $this->db->update('message', array('read_status' => 1));
    }

    function count_unread_message_of_thread($message_thread_code) {
        $unread_message_counter = 0;
        $current_user = $this->session->userdata('login_type') . '-' . $this->session->userdata('login_user_id');
        $messages = $this->get_where('message', array('message_thread_code' => $message_thread_code))->result_array();
        foreach ($messages as $row) {
            if ($row['sender'] != $current_user && $row['read_status'] == '0')
                $unread_message_counter++;
        }
        return $unread_message_counter;
    }

    function get_setting($key,$value="",$division_id=-1){
        if($division_id == null){
            $division_id = DIVISION_ID == null?-1:DIVISION_ID;
        }


        $q = $this->db->get_where('settings' , array('type'=>$key,'division_id'=>$division_id,'school_id'=>$GLOBALS['SCHOOL_ID']));
        if($q -> num_rows() > 0){
            return $q -> row() -> description;
        }
        $data['school_id'] = $GLOBALS['SCHOOL_ID'];
        $data['type'] = $key;
        $data['description'] = $value;
        $data['division_id'] = $division_id;
        $this->db->insert("settings",$data);
        return $value;
    }

    function set_setting($key,$value,$division_id=-1){
        if($division_id == null){
            $division_id = DIVISION_ID == null?-1:DIVISION_ID;
        }
        $value = $value == null?"":$value;
        $q = $this->db->get_where('settings' , array('type'=>$key,'division_id'=>$division_id,'school_id'=>$GLOBALS['SCHOOL_ID']));
        if($q -> num_rows() > 0){
            $this->db->where("type",$key);
            $this->db->where('school_id', $GLOBALS['SCHOOL_ID']);
            $this->db->where('division_id', $division_id);
            $this->db->update("settings",array('description'=>$value));
            return true;
        }
        $data['school_id'] = $GLOBALS['SCHOOL_ID'];
        $data['type'] = $key;
        $data['description'] = $value;
        $data['division_id'] = $division_id;
        $this->db->insert("settings",$data);
        return true;
    }

    function where($key,$value=null){
        return $this->db->where($key,$value);
    }

    function get($table){
        return $this->get_where($table,array());
    }

    function get_where($table,$config,$value=null){
        if(!is_array($config)){
            $key = $config;
            $config = array();
            $config[$key] = $value;
        }
        $config['school_id'] = $GLOBALS['SCHOOL_ID'];

        if(isset($config['division_id'])){
            if($config['division_id'] = "" || $config['division_id'] === false){
                unset($config['division_id']);
            }
        }else{
            $config['division_id'] = DIVISION_ID;
        }
        return $this->db->get_where($table,$config);
    }

    function insert($table,$config){
        $config['school_id'] = $GLOBALS['SCHOOL_ID'];
        $config['division_id'] = DIVISION_ID;
        return $this->db->insert($table,$config);
    }

    function update($table,$data){
        $this->db->where('school_id', $GLOBALS['SCHOOL_ID']);
        $this->db->where('division_id', DIVISION_ID);
        return $this->db->update($table,$data);
    }

    function delete($table){
        $this->db->where('school_id', $GLOBALS['SCHOOL_ID']);
        $this->db->where('division_id', DIVISION_ID);
        return $this->db->delete($table);
    }

    function insert_id(){
        return $this->db->insert_id();
    }

    function previous_term($term_id){
        $session_id = $this->get_where("term", array("term_id" => $term_id))->row()->year_id;

        $sessions = $this->get_where("year",array("year_id"=>$session_id))->row();

        $my_order = $sessions -> myorder;

        $terms = $this->get_where("term",array("year_id"=>$session_id))->result_array();

        $terms = $this->rearrange($terms,$my_order,"term_id");

        $count = 0;
        foreach($terms as $term){
            if($term['term_id'] == $term_id){
                break;
            }
            $count++;
        }
        $count--;
        return isset($terms[$count])?$terms[$count]['term_id']:0;
    }

    function get_students_result($term_id,$class_id){

        $exams = $this->get_where("exam",array("class_id"=>$class_id))->result_array();

        $session_id = $this->get_where("term", array("term_id" => $term_id))->row()->year_id;

        $sessions = $this->get_where("year",array("year_id"=>$session_id))->row();

        $my_order = $sessions -> myorder;

        $terms = $this->get_where("term",array("year_id"=>$session_id))->result_array();

        $terms = $this->rearrange($terms,$my_order,"term_id");

        $subjects = $this->get_where("subject",array("class_id"=>$class_id))->result_array();

        $students = $this->get_where("student",array("class_id"=>$class_id))->result_array();


        $my_mark = array();
        $marks = 	$this->get_where('mark' , array(
            'class_id' => $class_id
        ))->result_array();

        $my_exams = array();
        foreach($exams as $exam){
            $my_exams[$exam['exam_id']] = $exam['term_id'];
        }

        foreach($marks as $mark){
            $score = $mark['mark_obtained'];
            if(isset($my_exams[$mark['exam_id']])){
                $my_mark[$mark['student_id']][$my_exams[$mark['exam_id']]][$mark['subject_id']][$mark['exam_id']] = $score;
            }
        }

        $real_exams = array();
        foreach($exams as $exam){
            $real_exams[$exam['term_id']][] = $exam;
        }

        $pos = array();
        $myp = array();
        foreach($students as $student){
            $total = 0;

            foreach($terms as $term) {
                $term_total = 0;
                $my_mark[$student['student_id']][$term['term_id']]['per_total'] = 0;
                foreach ($subjects as $subject) {
                    $subtotal = 0;
                    $real_myexam = isset($real_exams[$term['term_id']])?$real_exams[$term['term_id']]:array();
                    foreach ($real_myexam as $exam) {
                        if (!isset($my_mark[$student['student_id']][$term['term_id']][$subject['subject_id']][$exam['exam_id']])) {
                            $my_mark[$student['student_id']][$term['term_id']][$subject['subject_id']][$exam['exam_id']] = 0;
                        }
                        $score = $my_mark[$student['student_id']][$term['term_id']][$subject['subject_id']][$exam['exam_id']];

                        $subtotal += $score;
                        $total += $score;
                        $term_total += $score;
                        @$my_mark[$student['student_id']][$term['term_id']]['per_total'] += $exam['mark'];

                    }

                    $my_mark[$student['student_id']][$term['term_id']][$subject['subject_id']]['total'] = $subtotal;

                }

                $myp['term_'.$term['term_id']][$student['student_id']] = $term_total;
                $myp['com_term_'.$term['term_id']][$student['student_id']] = $total;

                $my_mark[$student['student_id']][$term['term_id']]['total'] = $term_total;
                $my_mark[$student['student_id']][$term['term_id']]['com_total'] = $total;

                $grade_total = $my_mark[$student['student_id']][$term['term_id']]['per_total'];
                $my_mark[$student['student_id']][$term['term_id']]['per_total'] = $this->percentage($term_total,
                    $grade_total);
            }

            $my_mark[$student['student_id']]['total'] = $total;

        }


        foreach($terms as $term) {
            $this->getPosition($my_mark,$myp,'term_'.$term['term_id']);
            $this->getPosition($my_mark,$myp,'com_term_'.$term['term_id']);
        }

        return $my_mark;
        arsort($pos);

        $newp = 0;
        $prevp = 0;
        $pt = 0;
        foreach($pos as $id => $p){
            $newp++;
            if($pt == $p){
                $my_mark[$id]['position'] = $prevp;
            }else{
                $my_mark[$id]['position'] = $newp;
                $prevp = $newp;
            }

            $pt = $p;
        }

    }

    function getPosition(&$my_mark,$myp,$suffix){
        $pos = $myp[$suffix];
        arsort($pos);
        $newp = 0;
        $prevp = 0;
        $pt = 0;
        foreach($pos as $id => $p){
            $newp++;
            if($pt == $p){
                $my_mark[$id][$suffix] = $prevp;
            }else{
                $my_mark[$id][$suffix] = $newp;
                $prevp = $newp;
            }

            $pt = $p;
        }
    }

    function percentage($top,$botton){
        if($botton == 0 || $top == 0)
            return 0;
        return round(($top/$botton * 100),2);
    }

    function rearrange($array, $order, $id){
        if(!is_array($order))
            $order = explode(",",$order);

        $new_array = array();

        foreach($order as $x){
            foreach($array as $row){
                if(isset($row[$id]) && $row[$id] == $x){
                    $new_array[] = $row;
                    break;
                }
            }
        }

        if(count($new_array) != count($array)){
            foreach($array as $row){
                $p = false;
                foreach($new_array as $row_new){
                    if($row_new[$id] == $row[$id]){
                        $p = true;
                        break;
                    }
                }
                if(!$p)
                    $new_array[] = $row;
            }
        }

        return $new_array;
    }

    function ajaxSession(){
        $ajaxSession = Array();
        $myyears = $this->get('year')->result_array();
        foreach ($myyears as $year) {
            $terms = $this->get_where('term',array('year_id'=>$year['year_id']))->result_array();
            $terms = $this->rearrange($terms,$year['myorder'],"term_id");
            foreach($terms as $term){
                $ajaxSession[$year['year_id']][] = array("id"=>$term['term_id'],"name"=>$term['name']);;
            }
        }
        return $ajaxSession;
    }

    function print_list_terms($current_term = ""){
        echo '
        var currentterm = "',$current_term,'";
        var currentterm2 = currentterm;
        var session = ', json_encode($this->ajaxSession()),';
        function list_terms(ses,term){
            if(ses === undefined)
                var term_id = $("#session").val();
            else
                var term_id = $("#"+ses).val();
            if(term === undefined)
                 $el = $("#term");
            else
                 $el = $("#"+term);
            try {
                $el.html("");
                var lop = session[term_id];
                $.each(lop, function (key, value) {
                    if(currentterm == value.id){
                        $el.append($("<option selected></option>")
                            .attr("value", value.id).text(value.name));
                    }else{
                        $el.append($("<option></option>")
                            .attr("value", value.id).text(value.name));
                    }
                });
            } catch (e) {}
            }
            list_terms();
            currentterm = "";
        ';
    }

    function all_access($id = null){
        $array = array('login','admit_student','view_students','update_student','delete_student','create_teacher','update_teacher','delete_teacher','view_teachers','view_parents','manage_parents','view_classes','view_subjects','manage_subject','view_routines','manage_routine','view_attendance','view_exams','view_grades','manage_marks','send_marks','view_marks','view_results','access_cbt','manage_cbt','view_division','manage_division','view_sections','view_attendances','manage_attendance','manage_exam','view_result','accept_payment','create_invoice','update_invoice','delete_invoice','view_invoices','view_expenses','manage_expenses','view_books','view_transports','view_board','view_messages','manage_settings','manage_sms','manage_languages','view_divisions','manage_division','manage_class','view_terms','manage_session','manage_segment','manage_term','manage_terms','view_permissions','manage_permissions','change_user_password' );
        if($id != null){
            return isset($array[$id])?$array[$id]:"";
        }
        return $array;
    }

    function convert_permission($perm,$asArray=false){
        $x = explode(",",$perm);
        foreach($x as &$p){
            $p = ucwords(str_replace("_"," ",$p));
        }
        return !$asArray?implode(", ",$x):$x;
    }

    function isStudent(){
        return $this->session->userdata("login_as") == "student";
    }

    function isTeacher(){
        return $this->session->userdata("login_as") == "teacher";
    }

    function isAdmin(){
        return $this->session->userdata("login_as") == "admin";
    }

    function isParent(){
        return $this->session->userdata("login_as") == "parent";
    }

    function get_student_form($options = array("required_all"=>false)){
        $division_id = isset($options['required_all'])?$options['required_all']:DIVISION_ID;
        $class = $this->get_where("class",array("division_id"=>$division_id))->result_array();
        $class_ids = array();
        foreach($class as $row){
            $class_ids[$row['class_id']] = $row['name'];
        }

        $parent = $this->get("parent")->result_array();
        $parent_id = array();
        foreach($parent as $row){
            $parent_id[$row['parent_id']] = $row['name'];
        }
        $required_all = isset($options['required_all'])?$options['required_all']:true;

        $except = isset($options['except'])?explode(",",$options['except']):array();

        $fields = $this->db->list_fields("student");
        $change = array(
            "student_id"=>array("type"=>"hidden"),
            "surname" => array("label"=>"Surname","required"=>true),
            "fname" => array("label"=>"First Name","required"=>true),
            "mname" => array("label"=>"Middle Name"),
            "parent_id" => array("label"=>"Parent","type"=>"select","options"=>$parent_id),
            "sex" => array("type"=>"radio", "options"=>array("male","female")),
            "lga" => array("label"=>"LGA"),
            "password" => array("type"=>"password"),
            "hear_about_us" => array("label"=>"How did you get to know about us"),
            "others" => array("label"=>"Other Relevant Information"),
            "permanent_address" => array("type"=>"textarea"),
            "primary_language" => array("type"=>"text"),
            "religion" => array("type"=>"select","options"=>array("muslim"=>"Muslim","christian"=>"Christian","others"=>"Others")),
            "last_school" => array("type"=>"text", "label"=>"Name and Address of Last School Attended"),
            "last_school_duration" => array("type"=>"text", "label"=>"Duration in last school"),
            "last_school_reason" => array("type"=>"text", "label"=>"Reason for leaving"),
            "class_id" => array("type"=>"select", "label"=>"Class Appling For", "options"=>$class_ids),
        );

        $skip = array("school_id","division_id","dormitory_id","dormitory_room_number","access","dirty","deleted","rowversion","transport_id");

        $studentform = array();

        foreach($fields as $field){

            if(in_array($field,$skip))
                continue;

            if(isset($options['student'])){
                $student = $options['student'];
                $studentform[$field]['value'] = isset($student[$field])?$student[$field]:"";
            }
            $studentform[$field]['type'] = "text";
            $studentform[$field]['label'] = ucwords(str_replace(array("c1","c2","_","address1","address2"),array("",""," ","Home Address","Office Address"),$field));

            if($required_all){
                $studentform[$field]['required'] = !in_array($field,$except);
            }else{
                $studentform[$field]['required'] = in_array($field,$except);
            }
            if(isset($change[$field])){
                $row = $change[$field];
                if(isset($row['type'])){
                    $studentform[$field]['type'] = $row['type'];
                }
                if(isset($row['label'])){
                    $studentform[$field]['label'] = $row['label'];
                }
                if(isset($row['options'])){
                    $studentform[$field]['options'] = $row['options'];
                }

                if(isset($row['required'])){
                    $studentform[$field]['required'] = $row['required'];
                }


            }
        }
        return $studentform;

    }

    function create_input($options){
        $name = isset($options['name'])?$options['name']:"";
        $label = isset($options['label'])?$options['label']:"Value";
        $type = isset($options['type'])?$options['type']:"text";
        $value = isset($options['value'])?$options['value']:"";
        $class = isset($options['class'])?$options['class']:"form-control";
        $showclass = isset($options['showclass'])?$options['showclass']:"text-warning";
        $required = isset($options['required']) && $options['required']?"data-validate='required' data-message-required='$label Required'":"";
        $op = isset($options['options'])?$options['options']:array();
        $onlyshow = isset($options['onlyshow'])?$options['onlyshow']:false;

        if($onlyshow){
            $show = $value;
            if($type == "select" || $type == "radio" || $type == "checkbox"){
                $show = "";
                foreach($op as $k => $v){
                    if($k == $value){
                        $show = ucwords($v); break;
                    }
                }
            }

            if($type == "password"){
                $show = "*********";
            }

            if($type == "image"){
                $options['type'] = $options['type_'];
                return $this->construct_image($options);
            }

            return "<span class='$showclass form-control' style='border: none; color: #4e1c1c;'>$show</span>";
        }

        $value = is_array($value)?$value:htmlspecialchars($value);

        if($type == "textarea"){
            return "<textarea class='$class' rows='4' name='$name' $required>$value</textarea>";
        }

        if($type == "select"){
            $multiple = "";
            if(isset($options['multiple']) && $options['multiple']){
                $multiple = "multiple='multiple'";
                $class .= " select2";
            }
            $str = "<select class='$class' $multiple $required name='$name'>";
            if($multiple == ""){
                $str .= "<option value=''>Select $label</option>";
            }
            foreach($op as $k => $v){
                if(is_array($value)){
                    $s = in_array($v,$value)?"selected":"";
                }else
                    $s = strtolower($k) == strtolower($value)?"selected":"";

                $str .= "<option $s value='$k'>".ucwords($v)."</option>";
            }
            $str .= "</select>";
            return $str;
        }

        if($type == "checkbox" || $type == "radio"){
            $str = "";
            $name = $name."";
            foreach($op as $v){
                $v1 = ucwords($v);
                $s = $v == $value?"checked=checked":"";
                $str .= "<div class='$type'><label><input $s type='$type' name='$name'
value='$v'
 $required> $v1 </label></div>";
            }
            return $str."";
        }

        if($type == "password"){
            $width = 70;
            if($value == ""){
                $width = 100;
            }
            return "<input style='width: $width%; display: inline-block' ".($value== ""?"":"disabled='disabled'")." type='$type'
 value='**********'
name='$name'
id='$name' class='$class' $required >".($value == ""?"":"<input style='width: 29%; margin-left: 1%; display: inline-block; '
type='button'
class='btn btn-success' onclick=\"$('#$name').removeAttr('disabled').val('').attr('required','required');\"
value='change'>");
        }

        if($type == "image"){
            $options['type'] = $options['type_'];
            return $this->construct_image($options);
        }

        return "<input type='$type' value='$value' name='$name' id='$name' class='$class'
$required >";
    }

    function app2student_id($appid){
        return (int) str_replace("app-","",strtolower($appid));
    }

    function app_id($student_id){
        return "APP-".$student_id;
    }

    function get_full_name($row){
        if(is_object($row))
            return ucwords($row->surname." ".$row->fname." ".$row->mname);

        return ucwords($row['surname']." ".$row['fname']." ".$row['mname']);
    }


    function get_teacher_form($options = array("required_all"=>false)){
        $division_id = isset($options['required_all'])?$options['required_all']:DIVISION_ID;
        $class = $this->get_where("class",array("division_id"=>$division_id))->result_array();
        $class_ids = array();
        foreach($class as $row){
            $class_ids[$row['class_id']] = $row['name'];
        }

        $my_access = $this->all_access();
        foreach($my_access as $k => $v)
            $my_access[$k] = str_replace("_"," ",ucwords($v));

        $parent = $this->get("parent")->result_array();
        $parent_id = array();
        foreach($parent as $row){
            $parent_id[$row['parent_id']] = $row['name'];
        }
        $required_all = isset($options['required_all'])?$options['required_all']:true;

        $except = isset($options['except'])?explode(",",$options['except']):array();

        $fields = $this->db->list_fields("teacher");
        $change = array(
            "teacher_id"=>array("type"=>"hidden"),
            "surname" => array("label"=>"Surname","required"=>true),
            "fname" => array("label"=>"First Name","required"=>true),
            "mname" => array("label"=>"Middle Name"),
            "parent_id" => array("label"=>"Parent","type"=>"select","options"=>$parent_id),
            "sex" => array("type"=>"radio", "options"=>array("male","female")),
            "marital_status" => array("type"=>"radio", "options"=>array("single","married")),
            "type_of_employment" => array("type"=>"select", "options"=>array("permanent","contract")),
            "is_academic" => array("type"=>"select","label"=>"Type of Staff", "options"=>array(1=>"academic staff",0=>"non academic staff")),
            "status" => array("type"=>"select", "options"=>array("resignation", "termination", "active service", "leave of absence")),
            "profession" => array("type"=>"select", "options"=>$this->teacher_profession("all")),
            "lga" => array("label"=>"LGA"),
            "password" => array("type"=>"password"),
            "address" => array("type"=>"textarea"),
            "access" => array("type"=>"select","name"=>"access[]","options"=>$my_access,"multiple"=>true, "label"=>"Specific Access"),
            "religion" => array("type"=>"select","options"=>array("muslim"=>"Muslim","christian"=>"Christian","others"=>"Others")),

        );

        $skip = array("school_id","division_id","documents","dormitory_id","dormitory_room_number","dirty","deleted","rowversion","transport_id");

        $studentform = array();

        foreach($fields as $field){

            if(in_array($field,$skip))
                continue;

            if(isset($options['teacher'])){
                $student = $options['teacher'];
                $studentform[$field]['value'] = isset($student[$field])?$student[$field]:"";
                if($field == "access"){
                    $studentform[$field]['value'] = explode(",",$student[$field]);
                    foreach($studentform[$field]['value'] as $k => $v)
                        $studentform[$field]['value'][$k] = str_replace("_"," ",ucwords($v));
                }
            }

            $studentform[$field]['type'] = "text";
            $studentform[$field]['label'] = ucwords(str_replace(array("c1","c2","_","address1","address2"),array("",""," ","Home Address","Office Address"),$field));
            $studentform[$field]['name'] = $field;
            if($required_all){
                $studentform[$field]['required'] = !in_array($field,$except);
            }else{
                $studentform[$field]['required'] = in_array($field,$except);
            }
            if(isset($change[$field])){
                $row = $change[$field];
                if(isset($row['type'])){
                    $studentform[$field]['type'] = $row['type'];
                }
                if(isset($row['label'])){
                    $studentform[$field]['label'] = $row['label'];
                }
                if(isset($row['options'])){
                    $studentform[$field]['options'] = $row['options'];
                }

                if(isset($row['required'])){
                    $studentform[$field]['required'] = $row['required'];
                }

                if(isset($row['multiple'])){
                    $studentform[$field]['multiple'] = $row['multiple'];
                }

                if(isset($row['name'])){
                    $studentform[$field]['name'] = $row['name'];
                }



            }
        }
        return $studentform;

    }

    function teacher_profession($id){
        $x = "Guardner/nursery,Minder,Head Teacher,Head Master,Administrative Secretary,Security,Liberian,Teacher,Admin & Account,Transporter";
        $p = explode(",",$x);
        if($id != "all")
            return @$p[$id];
        return $p;
    }

    function get_session($term_id){
        $row = $this->c_->get_where("term", array("term_id" =>   $term_id));
        if($row->num_rows() > 0){
            return $row->row()->year_id;
        }
        return "";
    }


}
